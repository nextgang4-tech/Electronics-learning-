# Keep OkHttp and model classes intact
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class com.aielectronics.gurupro.data.** { *; }
