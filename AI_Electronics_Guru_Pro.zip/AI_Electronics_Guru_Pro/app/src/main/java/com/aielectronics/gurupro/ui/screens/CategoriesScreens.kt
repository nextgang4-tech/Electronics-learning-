package com.aielectronics.gurupro.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.BookmarkItem
import com.aielectronics.gurupro.data.content.CategoriesData
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.util.bi

@Composable
fun CategoriesScreen(
    lang: AppLanguage,
    onSelectCategory: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) CategoriesData.allCategories
        else CategoriesData.allCategories.filter {
            it.titleHi.lowercase().contains(q) || it.titleEn.lowercase().contains(q)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = bi(lang, "🛠️ सभी 19 इलेक्ट्रॉनिक्स रिपेयर कैटेगरी", "🛠️ All 19 Electronics Repair Categories"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                placeholder = { Text(bi(lang, "कैटेगरी खोजें (जैसे LED, फैन, TV, SMPS)...", "Search category...")) }
            )
        }

        items(filtered, key = { it.id }) { cat ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectCategory(cat.id) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(cat.titleHi, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(cat.titleEn, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (cat.isHighVoltage) {
                        Row(
                            modifier = Modifier
                                .background(DangerRed.copy(alpha = 0.18f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = SafetyAmber, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("HV सुरक्षा", color = SafetyAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .background(SafeGreen.copy(alpha = 0.18f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Low-V", color = SafeGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryDetailScreen(
    categoryId: String,
    prefs: AppPreferences,
    lang: AppLanguage
) {
    val context = LocalContext.current
    val category = remember(categoryId) { CategoriesData.findById(categoryId) } ?: return
    var showHvDialog by remember(categoryId) { mutableStateOf(category.isHighVoltage) }
    var isBookmarked by remember(categoryId) {
        mutableStateOf(prefs.loadBookmarks().any { it.id == "cat_${category.id}" })
    }

    if (showHvDialog) {
        AlertDialog(
            onDismissRequest = { showHvDialog = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = DangerRed) },
            title = { Text("⚠️ हाई-वोल्टेज सुरक्षा चेतावनी", fontWeight = FontWeight.Bold, color = DangerRed) },
            text = {
                Text(
                    text = "${category.safetyWarning}\n\nयह मॉड्यूल केवल थ्योरी और सुरक्षित डायग्नोस्टिक शिक्षा के लिए है। अनट्रेन्ड बिगिनर्स लाइव 230V/हाई-वोल्टेज रिपेयर कभी न करें।",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(onClick = { showHvDialog = false }) {
                    Text("मैं समझ गया / सुरक्षित रहूंगा")
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(category.titleHi, style = MaterialTheme.typography.titleLarge, color = ElectricBlue)
                    Text(category.titleEn, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = {
                    val list = prefs.loadBookmarks().toMutableList()
                    val bmId = "cat_${category.id}"
                    if (isBookmarked) {
                        list.removeAll { it.id == bmId }
                        isBookmarked = false
                    } else {
                        list.add(0, BookmarkItem(bmId, "कैटेगरी", category.titleHi, "category_detail/${category.id}"))
                        isBookmarked = true
                    }
                    prefs.saveBookmarks(list)
                    Toast.makeText(
                        context,
                        if (isBookmarked) "बुकमार्क सेव हुआ" else "बुकमार्क हटाया गया",
                        Toast.LENGTH_SHORT
                    ).show()
                }) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Bookmark",
                        tint = ElectricBlue
                    )
                }
            }
        }

        // Mandatory Safety Card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (category.isHighVoltage) DangerRed.copy(alpha = 0.16f) else SafetyAmber.copy(alpha = 0.14f)
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (category.isHighVoltage) DangerRed else SafetyAmber,
                            RoundedCornerShape(14.dp)
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = if (category.isHighVoltage) "⚠️ हाई-वोल्टेज सुरक्षा चेतावनी (केवल थ्योरी व सुरक्षित जांच)" else "🛡️ सुरक्षा निर्देश",
                        fontWeight = FontWeight.Bold,
                        color = if (category.isHighVoltage) DangerRed else SafetyAmber,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(category.safetyWarning, fontSize = 13.sp)
                }
            }
        }

        item { DetailSectionCard(bi(lang, "⚙️ कार्यप्रणाली (Working Principle)", "⚙️ Working Principle"), category.workingPrinciple) }
        item { DetailBulletCard(bi(lang, "❗ आम खराबियां (Common Faults)", "❗ Common Faults"), category.commonFaults) }
        item { DetailBulletCard(bi(lang, "🔎 मुख्य कंपोनेंट्स की पहचान", "🔎 Component Identification"), category.componentIdentification) }
        item { DetailBulletCard(bi(lang, "🧪 सुरक्षित टेस्टिंग प्रक्रिया", "🧪 Safe Testing Procedures"), category.testingProcedures) }
        item { DetailSectionCard(bi(lang, "📘 रिपेयर थ्योरी (Repair Theory)", "📘 Repair Theory"), category.repairTheory) }
        item { DetailBulletCard(bi(lang, "🧰 ज़रूरी टूल्स (Tools Required)", "🧰 Tools Required"), category.toolsRequired) }
        item { DetailBulletCard(bi(lang, "🛡️ सुरक्षा सावधानियां", "🛡️ Safety Precautions"), category.safetyPrecautions) }
        item { DetailSectionCard(bi(lang, "🎓 बिगिनर के लिए पहला सबक", "🎓 Beginner Lesson"), category.beginnerLesson) }
    }
}

@Composable
fun DetailSectionCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = ElectricBlue, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Text(body, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
fun DetailBulletCard(title: String, items: List<String>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = ElectricBlue, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            items.forEach { line ->
                Text("• $line", fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
    }
}
