package com.aielectronics.gurupro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.ChatMessage
import com.aielectronics.gurupro.network.AiResult
import com.aielectronics.gurupro.network.GeminiApiClient
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.RoyalBlue
import com.aielectronics.gurupro.util.bi
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AiChatScreen(
    prefs: AppPreferences,
    lang: AppLanguage
) {
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val settings = prefs.loadSettings()

    var messages by remember { mutableStateOf(prefs.loadChatHistory()) }
    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val quickQuestions = listOf(
        "मेरा मोबाइल चार्जर काम नहीं कर रहा है",
        "मेरा LED बल्ब नहीं जल रहा है",
        "मेरा पंखा आवाज़ कर रहा है",
        "मेरे TV में डिस्प्ले नहीं आ रहा है",
        "मेरे स्पीकर में आवाज़ नहीं आ रही है",
        "मेरी पावर सप्लाई काम नहीं कर रही है",
        "मेरे PCB में एक कंपोनेंट जल गया है"
    )

    fun sendQuestion(question: String) {
        val clean = question.trim()
        if (clean.isEmpty() || isLoading) return
        val now = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val userMsg = ChatMessage("u_${System.currentTimeMillis()}", true, clean, now)
        val historyBefore = messages
        messages = messages + userMsg
        prefs.saveChatHistory(messages)
        inputText = ""

        scope.launch {
            isLoading = true
            val res = GeminiApiClient.sendRepairChat(
                apiKey = settings.apiKey,
                model = settings.modelName,
                history = historyBefore,
                newUserMessage = clean,
                lang = lang
            )
            isLoading = false
            val replyText = when (res) {
                is AiResult.Success -> res.data
                is AiResult.Error -> "⚠️ ${res.message}"
            }
            val aiMsg = ChatMessage(
                "a_${System.currentTimeMillis()}",
                false,
                replyText,
                SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            )
            messages = messages + aiMsg
            prefs.saveChatHistory(messages)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = bi(lang, "🤖 AI इलेक्ट्रॉनिक्स रिपेयर चैट", "🤖 AI Electronics Repair Chat"),
                    fontWeight = FontWeight.Bold,
                    color = ElectricBlue,
                    fontSize = 17.sp
                )
                Text(
                    text = bi(lang, "स्टेप-बाय-स्टेप सुरक्षित गाइड", "Step-by-step safe Hindi repair mentor"),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (messages.isNotEmpty()) {
                IconButton(onClick = {
                    prefs.clearChatHistory()
                    messages = emptyList()
                }) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Chat")
                }
            }
        }

        // Quick-start example chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(quickQuestions) { q ->
                SuggestionChip(
                    onClick = { sendQuestion(q) },
                    label = { Text(q, fontSize = 12.sp) }
                )
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = bi(
                                lang,
                                "नमस्ते! मैं आपका AI Electronics Guru हूँ। ऊपर दिए गए किसी उदाहरण पर टैप करें या नीचे अपनी समस्या हिंदी/Hinglish में लिखें। मैं आपसे सही सवाल पूछकर सुरक्षित तरीके से गाइड करूँगा।",
                                "Namaste! Main aapka AI Electronics Guru hoon. Upar ke example par tap karein ya neeche apni problem likhein."
                            ),
                            modifier = Modifier.padding(14.dp),
                            fontSize = 14.sp
                        )
                    }
                }
            }

            items(messages, key = { it.id }) { msg ->
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (msg.isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.88f)
                            .background(
                                if (msg.isUser) RoyalBlue else MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(14.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Text(
                            text = msg.text,
                            color = if (msg.isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = msg.timestamp,
                            fontSize = 10.sp,
                            color = if (msg.isUser) Color.White.copy(alpha = 0.75f) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(bi(lang, "AI गुरु जवाब लिख रहे हैं...", "AI Guru jawab likh rahe hain..."), fontSize = 13.sp)
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                placeholder = {
                    Text(bi(lang, "अपना रिपेयर सवाल लिखें...", "Apna repair sawal likhein..."), fontSize = 13.sp)
                },
                maxLines = 3
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = { sendQuestion(inputText) },
                enabled = inputText.isNotBlank() && !isLoading,
                modifier = Modifier
                    .size(48.dp)
                    .background(ElectricBlue, RoundedCornerShape(24.dp))
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.Black)
            }
        }
    }
}
