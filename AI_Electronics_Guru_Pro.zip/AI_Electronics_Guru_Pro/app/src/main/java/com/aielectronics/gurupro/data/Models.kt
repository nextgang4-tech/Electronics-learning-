package com.aielectronics.gurupro.data

enum class AppLanguage { HINDI, HINGLISH }

enum class ThemeMode { DARK, LIGHT, SYSTEM }

data class AppSettings(
    val apiKey: String = "",
    val modelName: String = "gemini-2.5-flash",
    val imageApiModel: String = "",
    val language: AppLanguage = AppLanguage.HINDI,
    val themeMode: ThemeMode = ThemeMode.DARK
)

data class RepairCategory(
    val id: String,
    val titleHi: String,
    val titleEn: String,
    val iconName: String,
    val isHighVoltage: Boolean,
    val safetyWarning: String,
    val workingPrinciple: String,
    val commonFaults: List<String>,
    val componentIdentification: List<String>,
    val testingProcedures: List<String>,
    val repairTheory: String,
    val toolsRequired: List<String>,
    val safetyPrecautions: List<String>,
    val beginnerLesson: String
)

data class MultimeterLesson(
    val id: String,
    val titleHi: String,
    val titleEn: String,
    val diagramType: String,
    val isHighVoltageWarning: Boolean,
    val safetyRule: String,
    val dialSetting: String,
    val socketToUse: String,
    val blackProbePlacement: String,
    val redProbePlacement: String,
    val expectedReading: String,
    val readingMeanings: List<String>
)

data class SolderingLesson(
    val id: String,
    val titleHi: String,
    val titleEn: String,
    val diagramType: String,
    val summary: String,
    val steps: List<String>,
    val proTips: List<String>,
    val safetyNote: String
)

data class ComponentItem(
    val id: String,
    val nameHi: String,
    val nameEn: String,
    val pcbMarkings: List<String>,
    val diagramType: String,
    val purpose: String,
    val symbolDescription: String,
    val pinout: String,
    val testingMethod: String,
    val safetyNote: String
)

data class CircuitLesson(
    val id: String,
    val titleHi: String,
    val titleEn: String,
    val diagramType: String,
    val overview: String,
    val keyPoints: List<String>,
    val troubleshootingSteps: List<String>
)

data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

data class CourseLevel(
    val level: Int,
    val titleHi: String,
    val titleEn: String,
    val lessonContent: String,
    val practiceQuestions: List<String>,
    val quiz: List<QuizQuestion>
)

data class DictionaryTerm(
    val term: String,
    val hindiMeaning: String,
    val simpleExample: String
)

data class ComponentPriceItem(
    val id: String,
    val name: String,
    val specs: String,
    val estimatedPriceInr: Int
)

data class RepairNote(
    val id: String,
    val title: String,
    val device: String,
    val content: String,
    val timestamp: String
)

data class SavedRepairCase(
    val id: String,
    val title: String,
    val source: String,
    val analysisText: String,
    val timestamp: String
)

data class BookmarkItem(
    val id: String,
    val type: String,
    val title: String,
    val route: String
)

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: String
)

data class SafetyTopic(
    val id: String,
    val title: String,
    val dangerLevel: String,
    val explanation: String,
    val rule: String
)

data class RepairChecklistItem(
    val id: String,
    val title: String,
    val detail: String
)

data class SearchResultItem(
    val title: String,
    val subtitle: String,
    val badge: String,
    val route: String
)
