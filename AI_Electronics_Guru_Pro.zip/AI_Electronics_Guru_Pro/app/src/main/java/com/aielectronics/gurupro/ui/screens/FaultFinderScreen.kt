package com.aielectronics.gurupro.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Troubleshoot
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.SavedRepairCase
import com.aielectronics.gurupro.data.content.CategoriesData
import com.aielectronics.gurupro.network.AiResult
import com.aielectronics.gurupro.network.GeminiApiClient
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.util.CompressedPhoto
import com.aielectronics.gurupro.util.ImageUtils
import com.aielectronics.gurupro.util.bi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FaultFinderScreen(
    prefs: AppPreferences,
    lang: AppLanguage
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = prefs.loadSettings()

    var selectedAppliance by remember { mutableStateOf(CategoriesData.allCategories.first().titleHi) }
    var symptoms by remember { mutableStateOf("") }
    var measurements by remember { mutableStateOf("") }
    var attachedPhotos by remember { mutableStateOf<List<CompressedPhoto>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var resultText by remember { mutableStateOf<String?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val galleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 3)
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                val compressed = withContext(Dispatchers.IO) {
                    uris.mapNotNull { ImageUtils.compressUriForAi(context, it) }
                }
                attachedPhotos = compressed
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "🛠️ AI फॉल्ट फाइंडर (7-स्टेप डायग्नोसिस)", "🛠️ AI Fault Finder (7-Step Diagnosis)"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = bi(
                    lang,
                    "उपकरण चुनें, लक्षण बताएं, और चाहें तो मल्टीमीटर माप व फोटो जोड़ें। AI काल्पनिक वैल्यू नहीं बनाएगा — केवल सुरक्षित क्रमबद्ध जांच बताएगा।",
                    "Appliance select karein, symptoms likhein aur optional photo/measurements add karein."
                ),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Text(bi(lang, "1. उपकरण चुनें:", "1. Select Appliance:"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CategoriesData.allCategories) { cat ->
                    FilterChip(
                        selected = selectedAppliance == cat.titleHi,
                        onClick = { selectedAppliance = cat.titleHi },
                        label = { Text(cat.titleHi, fontSize = 12.sp) }
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = symptoms,
                onValueChange = { symptoms = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(bi(lang, "2. लक्षण / समस्या लिखें *", "2. Symptoms / Problem *")) },
                placeholder = { Text(bi(lang, "जैसे: लाइट जलती है पर आउटपुट नहीं आ रहा, या हल्की बीप आ रही है...", "Jaise: LED jal rahi hai par output nahi hai...")) },
                minLines = 3
            )
        }

        item {
            OutlinedTextField(
                value = measurements,
                onValueChange = { measurements = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(bi(lang, "3. मल्टीमीटर माप (यदि आपने लिए हों — वैकल्पिक)", "3. Multimeter Measurements (Optional)")) },
                placeholder = { Text(bi(lang, "जैसे: बैटरी पर 3.2V DC आ रहा है, फ्यूज़ बीप कर रहा है", "Jaise: Battery 3.2V DC, fuse beep OK")) },
                minLines = 2
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (attachedPhotos.isEmpty()) bi(lang, "फोटो जोड़ें (वैकल्पिक)", "Attach Photos (Optional)")
                        else "${attachedPhotos.size} फोटो जुड़ी हैं ✔",
                        fontSize = 12.sp
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    errorText = null
                    resultText = null
                    scope.launch {
                        isLoading = true
                        val res = GeminiApiClient.runFaultFinder(
                            apiKey = settings.apiKey,
                            model = settings.modelName,
                            appliance = selectedAppliance,
                            symptoms = symptoms,
                            measurements = measurements,
                            base64Images = attachedPhotos.map { it.base64Jpeg },
                            lang = lang
                        )
                        isLoading = false
                        when (res) {
                            is AiResult.Success -> resultText = res.data
                            is AiResult.Error -> errorText = res.message
                        }
                    }
                },
                enabled = symptoms.isNotBlank() && !isLoading,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text(bi(lang, "डायग्नोसिस तैयार हो रहा है...", "Diagnosing..."))
                } else {
                    Icon(Icons.Default.Troubleshoot, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(bi(lang, "AI फॉल्ट डायग्नोसिस शुरू करें", "Start AI Fault Diagnosis"), fontWeight = FontWeight.Bold)
                }
            }
        }

        if (errorText != null) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.16f))) {
                    Text(errorText.orEmpty(), modifier = Modifier.padding(12.dp), color = DangerRed)
                }
            }
        }

        if (resultText != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = bi(lang, "डायग्नोसिस रिपोर्ट", "Diagnosis Report"),
                                fontWeight = FontWeight.Bold,
                                color = SafeGreen,
                                fontSize = 16.sp
                            )
                            OutlinedButton(
                                onClick = {
                                    val now = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                                    val item = SavedRepairCase(
                                        id = "ff_${System.currentTimeMillis()}",
                                        title = "$selectedAppliance: ${symptoms.take(28)}",
                                        source = "AI Fault Finder",
                                        analysisText = resultText.orEmpty(),
                                        timestamp = now
                                    )
                                    val list = prefs.loadSavedCases().toMutableList()
                                    list.add(0, item)
                                    prefs.saveSavedCases(list)
                                    Toast.makeText(context, "केस सेव हो गया!", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(bi(lang, "सेव करें", "Save"), fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(resultText.orEmpty(), fontSize = 14.sp, lineHeight = 21.sp)
                    }
                }
            }
        }
    }
}
