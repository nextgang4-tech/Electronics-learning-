package com.aielectronics.gurupro.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.AppSettings
import com.aielectronics.gurupro.data.ThemeMode
import com.aielectronics.gurupro.ui.screens.AiChatScreen
import com.aielectronics.gurupro.ui.screens.CategoriesScreen
import com.aielectronics.gurupro.ui.screens.CategoryDetailScreen
import com.aielectronics.gurupro.ui.screens.CircuitLearningScreen
import com.aielectronics.gurupro.ui.screens.ComponentsScreen
import com.aielectronics.gurupro.ui.screens.CourseScreen
import com.aielectronics.gurupro.ui.screens.DashboardScreen
import com.aielectronics.gurupro.ui.screens.FaultFinderScreen
import com.aielectronics.gurupro.ui.screens.MultimeterScreen
import com.aielectronics.gurupro.ui.screens.PhotoScannerScreen
import com.aielectronics.gurupro.ui.screens.SettingsScreen
import com.aielectronics.gurupro.ui.screens.SolderingScreen
import com.aielectronics.gurupro.ui.screens.ToolsHubScreen
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.util.bi

private data class BottomNavItem(
    val route: String,
    val labelHi: String,
    val labelEn: String,
    val icon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavHost(
    prefs: AppPreferences,
    settings: AppSettings,
    onSettingsUpdated: (AppSettings) -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: "home"
    val lang = settings.language

    val bottomItems = listOf(
        BottomNavItem("home", "होम", "Home", Icons.Default.Home),
        BottomNavItem("scanner", "AI स्कैन", "Scan", Icons.Default.CameraAlt),
        BottomNavItem("chat", "AI चैट", "Chat", Icons.Default.Chat),
        BottomNavItem("course", "कोर्स", "Course", Icons.Default.School),
        BottomNavItem("tools", "टूल्स", "Tools", Icons.Default.Build)
    )
    val topLevelRoutes = bottomItems.map { it.route }.toSet()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "AI Electronics Guru Pro",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = ElectricBlue
                    )
                },
                navigationIcon = {
                    if (currentRoute !in topLevelRoutes) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val nextTheme = if (settings.themeMode == ThemeMode.DARK) ThemeMode.LIGHT else ThemeMode.DARK
                        val updated = settings.copy(themeMode = nextTheme)
                        prefs.saveSettings(updated)
                        onSettingsUpdated(updated)
                    }) {
                        Icon(
                            imageVector = if (settings.themeMode == ThemeMode.DARK) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Theme"
                        )
                    }
                    IconButton(onClick = { navController.navigate("settings") }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                bottomItems.forEach { item ->
                    val selected = currentRoute == item.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            if (!selected) {
                                navController.navigate(item.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.labelEn) },
                        label = { Text(bi(lang, item.labelHi, item.labelEn), fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") {
                DashboardScreen(
                    prefs = prefs,
                    lang = lang,
                    onNavigate = { route -> navController.navigate(route) }
                )
            }
            composable("scanner") {
                PhotoScannerScreen(
                    prefs = prefs,
                    lang = lang,
                    onOpenSettings = { navController.navigate("settings") }
                )
            }
            composable("chat") {
                AiChatScreen(prefs = prefs, lang = lang)
            }
            composable("fault_finder") {
                FaultFinderScreen(prefs = prefs, lang = lang)
            }
            composable("categories") {
                CategoriesScreen(
                    lang = lang,
                    onSelectCategory = { id -> navController.navigate("category_detail/$id") }
                )
            }
            composable(
                route = "category_detail/{categoryId}",
                arguments = listOf(navArgument("categoryId") { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString("categoryId").orEmpty()
                CategoryDetailScreen(categoryId = id, prefs = prefs, lang = lang)
            }
            composable("multimeter") {
                MultimeterScreen(lang = lang)
            }
            composable("soldering") {
                SolderingScreen(lang = lang)
            }
            composable("components") {
                ComponentsScreen(prefs = prefs, lang = lang)
            }
            composable("circuits") {
                CircuitLearningScreen(lang = lang)
            }
            composable("course") {
                CourseScreen(prefs = prefs, lang = lang)
            }
            composable("tools") {
                ToolsHubScreen(
                    prefs = prefs,
                    lang = lang,
                    onNavigate = { route -> navController.navigate(route) }
                )
            }
            composable("settings") {
                SettingsScreen(
                    prefs = prefs,
                    currentSettings = settings,
                    onSettingsUpdated = onSettingsUpdated
                )
            }
        }
    }
}
