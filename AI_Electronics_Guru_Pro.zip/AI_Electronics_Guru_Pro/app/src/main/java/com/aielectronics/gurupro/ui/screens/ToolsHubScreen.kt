package com.aielectronics.gurupro.ui.screens

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.ComponentPriceItem
import com.aielectronics.gurupro.data.RepairNote
import com.aielectronics.gurupro.data.content.ExtrasData
import com.aielectronics.gurupro.network.AiResult
import com.aielectronics.gurupro.network.GeminiApiClient
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.util.bi
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.pow

private enum class ToolTab(val labelHi: String) {
    CALCULATORS("कैलकुलेटर"),
    AI_DIAGRAM("AI डायग्राम"),
    PRICES("पार्ट्स कीमत"),
    DICTIONARY("हिंदी डिक्शनरी"),
    NOTES_CASES("नोट्स व केस"),
    BOOKMARKS_CHECKLIST("चेकलिस्ट व बुकमार्क"),
    SAFETY("सुरक्षा केंद्र")
}

@Composable
fun ToolsHubScreen(
    prefs: AppPreferences,
    lang: AppLanguage,
    onNavigate: (String) -> Unit
) {
    var activeTab by remember { mutableStateOf(ToolTab.CALCULATORS) }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ToolTab.entries) { tab ->
                FilterChip(
                    selected = activeTab == tab,
                    onClick = { activeTab = tab },
                    label = { Text(tab.labelHi, fontSize = 12.sp) }
                )
            }
        }

        when (activeTab) {
            ToolTab.CALCULATORS -> CalculatorsSection(lang)
            ToolTab.AI_DIAGRAM -> AiDiagramGeneratorSection(prefs, lang, onNavigate)
            ToolTab.PRICES -> ComponentPriceSection(prefs, lang)
            ToolTab.DICTIONARY -> DictionarySection(lang)
            ToolTab.NOTES_CASES -> NotesAndCasesSection(prefs, lang)
            ToolTab.BOOKMARKS_CHECKLIST -> BookmarksAndChecklistSection(prefs, lang, onNavigate)
            ToolTab.SAFETY -> SafetyCenterSection(lang)
        }
    }
}

@Composable
private fun CalculatorsSection(lang: AppLanguage) {
    // 1. Ohm's Law
    var voltStr by remember { mutableStateOf("12") }
    var resStr by remember { mutableStateOf("1000") }

    // 2. LED Resistor
    var ledSupply by remember { mutableStateOf("9") }
    var ledVf by remember { mutableStateOf("2.0") }
    var ledMa by remember { mutableStateOf("20") }

    // 3. Series / Parallel
    var r1Str by remember { mutableStateOf("100") }
    var r2Str by remember { mutableStateOf("220") }

    // 4. Resistor Color Code (4-band)
    val bandColors = listOf(
        "काला (0)" to Color(0xFF111827),
        "भूरा (1)" to Color(0xFF78350F),
        "लाल (2)" to Color(0xFFDC2626),
        "नारंगी (3)" to Color(0xFFEA580C),
        "पीला (4)" to Color(0xFFEAB308),
        "हरा (5)" to Color(0xFF16A34A),
        "नीला (6)" to Color(0xFF2563EB),
        "बैंगनी (7)" to Color(0xFF7C3AED),
        "ग्रे (8)" to Color(0xFF6B7280),
        "सफेद (9)" to Color(0xFFF8FAFC)
    )
    var b1 by remember { mutableIntStateOf(1) } // Brown = 1
    var b2 by remember { mutableIntStateOf(0) } // Black = 0
    var b3 by remember { mutableIntStateOf(2) } // Red = x100 -> 1kΩ

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Ohm's Law & Power Calculator
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(bi(lang, "⚡ ओम का नियम व पावर कैलकुलेटर (V = I × R)", "⚡ Ohm's Law & Power Calculator"), fontWeight = FontWeight.Bold, color = ElectricBlue)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = voltStr,
                            onValueChange = { voltStr = it },
                            label = { Text("वोल्टेज (V)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = resStr,
                            onValueChange = { resStr = it },
                            label = { Text("रेजिस्टेंस (Ω)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    val v = voltStr.toDoubleOrNull() ?: 0.0
                    val r = resStr.toDoubleOrNull() ?: 0.0
                    val result = if (r > 0) {
                        val currentA = v / r
                        val powerW = v * currentA
                        "करंट (I) = ${"%.4f".format(currentA)} A (${"%.1f".format(currentA * 1000)} mA)\nपावर (P) = ${"%.3f".format(powerW)} Watt"
                    } else "सही रेजिस्टेंस (> 0) दर्ज करें।"
                    Text(result, color = SafeGreen, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }

        // Resistor Color Code Calculator
        item {
            val ohms = (b1 * 10 + b2) * 10.0.pow(b3.toDouble())
            val formattedOhms = when {
                ohms >= 1_000_000 -> "${"%.2f".format(ohms / 1_000_000)} MΩ ±5%"
                ohms >= 1_000 -> "${"%.2f".format(ohms / 1_000)} kΩ ±5%"
                else -> "${ohms.toInt()} Ω ±5%"
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🎨 रेजिस्टर कलर कोड कैलकुलेटर (4-Band)", fontWeight = FontWeight.Bold, color = ElectricBlue)
                    // Visual resistor strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .background(Color(0xFFD6B98C), RoundedCornerShape(22.dp))
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(14.dp).height(44.dp).background(bandColors[b1].second))
                        Box(Modifier.width(14.dp).height(44.dp).background(bandColors[b2].second))
                        Box(Modifier.width(14.dp).height(44.dp).background(bandColors[b3].second))
                        Box(Modifier.width(10.dp).height(44.dp).background(Color(0xFFD4AF37))) // Gold 5%
                    }
                    Text("मान (Value): $formattedOhms", color = SafeGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { b1 = (b1 + 1) % 10 }, modifier = Modifier.weight(1f)) {
                            Text("बैंड 1: $b1", fontSize = 11.sp)
                        }
                        OutlinedButton(onClick = { b2 = (b2 + 1) % 10 }, modifier = Modifier.weight(1f)) {
                            Text("बैंड 2: $b2", fontSize = 11.sp)
                        }
                        OutlinedButton(onClick = { b3 = (b3 + 1) % 7 }, modifier = Modifier.weight(1f)) {
                            Text("गुणा: 10^$b3", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // LED Resistor Calculator
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("💡 LED रेजिस्टर कैलकुलेटर", fontWeight = FontWeight.Bold, color = ElectricBlue)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = ledSupply, onValueChange = { ledSupply = it },
                            label = { Text("सप्लाई (V)") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = ledVf, onValueChange = { ledVf = it },
                            label = { Text("LED (V)") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = ledMa, onValueChange = { ledMa = it },
                            label = { Text("करंट (mA)") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    val vs = ledSupply.toDoubleOrNull() ?: 0.0
                    val vf = ledVf.toDoubleOrNull() ?: 0.0
                    val ma = ledMa.toDoubleOrNull() ?: 0.0
                    val ledRes = if (vs > vf && ma > 0) {
                        val r = (vs - vf) / (ma / 1000.0)
                        val w = (vs - vf) * (ma / 1000.0)
                        "ज़रूरी रेजिस्टर = ${"%.1f".format(r)} Ω | पावर = ${"%.3f".format(w)} W (आमतौर पर 1/4W पर्याप्त)"
                    } else "सप्लाई वोल्टेज LED वोल्टेज से अधिक होना चाहिए।"
                    Text(ledRes, color = SafeGreen, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }

        // Series & Parallel Calculator
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🔀 सीरीज़ और पैरेलल सर्किट कैलकुलेटर (R1 & R2)", fontWeight = FontWeight.Bold, color = ElectricBlue)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = r1Str, onValueChange = { r1Str = it },
                            label = { Text("R1 (Ω)") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = r2Str, onValueChange = { r2Str = it },
                            label = { Text("R2 (Ω)") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    val r1 = r1Str.toDoubleOrNull() ?: 0.0
                    val r2 = r2Str.toDoubleOrNull() ?: 0.0
                    val spText = if (r1 > 0 && r2 > 0) {
                        val series = r1 + r2
                        val parallel = (r1 * r2) / (r1 + r2)
                        "सीरीज़ (Series) = ${"%.2f".format(series)} Ω\nपैरेलल (Parallel) = ${"%.2f".format(parallel)} Ω"
                    } else "दोनों मान > 0 दर्ज करें।"
                    Text(spText, color = SafeGreen, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun AiDiagramGeneratorSection(
    prefs: AppPreferences,
    lang: AppLanguage,
    onNavigate: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val settings = prefs.loadSettings()
    var prompt by remember { mutableStateOf("7805 5V voltage regulator circuit diagram with filter capacitors") }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "🎨 AI इमेज और सर्किट डायग्राम जनरेटर", "🎨 AI Image & Diagram Generator"),
                style = MaterialTheme.typography.titleMedium,
                color = ElectricBlue
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = bi(
                    lang,
                    "शैक्षिक इलेक्ट्रॉनिक्स डायग्राम बनाने के लिए समर्थित Image Generation API आवश्यक है। यदि API कॉन्फ़िगर नहीं है, तो यह ऐप कभी भी नकली इमेज नहीं दिखाएगा।",
                    "Educational electronics diagram generate karne ke liye supported Image API configure hona zaroori hai."
                ),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (settings.apiKey.isBlank() || settings.imageApiModel.isBlank()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SafetyAmber.copy(alpha = 0.14f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("⚠️ इमेज जनरेशन API कॉन्फ़िगर नहीं है", fontWeight = FontWeight.Bold, color = SafetyAmber)
                        Text(
                            text = "सेटअप निर्देश:\n1. Settings में जाएं और अपनी Gemini API Key डालें।\n2. 'Image Generation Model' फ़ील्ड में समर्थित मॉडल (जैसे imagen-3.0-generate-002) दर्ज करके Save करें।\n3. तब तक आप ऑफलाइन सर्किट और कंपोनेंट वेक्टर डायग्राम बिना API के देख सकते हैं।",
                            fontSize = 13.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onNavigate("settings") }) { Text("Settings खोलें", fontSize = 12.sp) }
                            OutlinedButton(onClick = { onNavigate("circuits") }) { Text("ऑफलाइन डायग्राम देखें", fontSize = 12.sp) }
                        }
                    }
                }
            }
        } else {
            item {
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("डायग्राम का विवरण लिखें") },
                    minLines = 2
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        errorMsg = null
                        generatedBitmap = null
                        scope.launch {
                            isGenerating = true
                            val res = GeminiApiClient.generateEducationalDiagram(
                                apiKey = settings.apiKey,
                                imageModel = settings.imageApiModel,
                                prompt = prompt,
                                lang = lang
                            )
                            isGenerating = false
                            when (res) {
                                is AiResult.Success -> generatedBitmap = res.data
                                is AiResult.Error -> errorMsg = res.message
                            }
                        }
                    },
                    enabled = prompt.isNotBlank() && !isGenerating,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("डायग्राम बन रहा है...")
                    } else {
                        Text("AI डायग्राम बनाएं")
                    }
                }
            }
        }

        if (errorMsg != null) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.15f))) {
                    Text(errorMsg.orEmpty(), modifier = Modifier.padding(12.dp), color = DangerRed, fontSize = 13.sp)
                }
            }
        }

        if (generatedBitmap != null) {
            item {
                Image(
                    bitmap = generatedBitmap!!.asImageBitmap(),
                    contentDescription = "Generated Electronics Diagram",
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                )
            }
        }
    }
}

@Composable
private fun ComponentPriceSection(prefs: AppPreferences, lang: AppLanguage) {
    val context = LocalContext.current
    var prices by remember { mutableStateOf(prefs.loadComponentPrices()) }
    var newName by remember { mutableStateOf("") }
    var newSpecs by remember { mutableStateOf("") }
    var newPrice by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = bi(lang, "💰 कंपोनेंट कीमत अनुमान (Editable INR ₹)", "💰 Component Price Estimator (Editable ₹)"),
                style = MaterialTheme.typography.titleMedium,
                color = ElectricBlue
            )
            Text("स्थानीय मार्केट के अनुसार किसी भी पार्ट की कीमत + / - से बदलें या नया पार्ट जोड़ें।", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("पार्ट नाम") }, modifier = Modifier.weight(1.4f), singleLine = true)
                        OutlinedTextField(value = newPrice, onValueChange = { newPrice = it }, label = { Text("₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(0.7f), singleLine = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = newSpecs, onValueChange = { newSpecs = it }, label = { Text("स्पेसिफिकेशन (जैसे 12V 2A)") }, modifier = Modifier.weight(1f), singleLine = true)
                        Button(onClick = {
                            val p = newPrice.toIntOrNull()
                            if (newName.isNotBlank() && p != null) {
                                val updated = listOf(ComponentPriceItem("custom_${System.currentTimeMillis()}", newName.trim(), newSpecs.trim(), p)) + prices
                                prices = updated
                                prefs.saveComponentPrices(updated)
                                newName = ""; newSpecs = ""; newPrice = ""
                                Toast.makeText(context, "नया पार्ट जोड़ा गया", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        items(prices, key = { it.id }) { item ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (item.specs.isNotBlank()) Text(item.specs, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedButton(onClick = {
                        val updated = prices.map { if (it.id == item.id) it.copy(estimatedPriceInr = (it.estimatedPriceInr - 5).coerceAtLeast(1)) else it }
                        prices = updated; prefs.saveComponentPrices(updated)
                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("-") }
                    Text(" ₹${item.estimatedPriceInr} ", fontWeight = FontWeight.Bold, color = SafeGreen, fontSize = 15.sp)
                    OutlinedButton(onClick = {
                        val updated = prices.map { if (it.id == item.id) it.copy(estimatedPriceInr = it.estimatedPriceInr + 5) else it }
                        prices = updated; prefs.saveComponentPrices(updated)
                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("+") }
                }
            }
        }
    }
}

@Composable
private fun DictionarySection(lang: AppLanguage) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) ExtrasData.dictionaryTerms
        else ExtrasData.dictionaryTerms.filter {
            it.term.lowercase().contains(q) || it.hindiMeaning.lowercase().contains(q)
        }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text(bi(lang, "शब्द खोजें (जैसे SMPS, ESD, Ripple)...", "Search term...")) }
            )
        }
        items(filtered) { d ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(d.term, fontWeight = FontWeight.Bold, color = ElectricBlue, fontSize = 15.sp)
                    Text(d.hindiMeaning, fontSize = 13.sp)
                    Text("उदाहरण: ${d.simpleExample}", fontSize = 12.sp, color = SafeGreen)
                }
            }
        }
    }
}

@Composable
private fun NotesAndCasesSection(prefs: AppPreferences, lang: AppLanguage) {
    var notes by remember { mutableStateOf(prefs.loadRepairNotes()) }
    var cases by remember { mutableStateOf(prefs.loadSavedCases()) }
    var title by remember { mutableStateOf("") }
    var device by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(bi(lang, "📝 नया रिपेयर नोट लिखें", "📝 Add Repair Note"), fontWeight = FontWeight.Bold, color = ElectricBlue)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("शीर्षक") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(value = device, onValueChange = { device = it }, label = { Text("उपकरण (जैसे 12V चार्जर)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("विवरण / माप / समाधान") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        val now = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
                        val updated = listOf(RepairNote("n_${System.currentTimeMillis()}", title.trim(), device.trim(), content.trim(), now)) + notes
                        notes = updated; prefs.saveRepairNotes(updated)
                        title = ""; device = ""; content = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("नोट सेव करें") }
        }

        if (notes.isNotEmpty()) {
            item { Text("आपके रिपेयर नोट्स (${notes.size})", fontWeight = FontWeight.Bold, color = SafeGreen) }
            items(notes, key = { it.id }) { n ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(n.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${n.device} • ${n.timestamp}", fontSize = 11.sp, color = ElectricBlue)
                            Text(n.content, fontSize = 13.sp)
                        }
                        IconButton(onClick = {
                            notes = notes.filterNot { it.id == n.id }
                            prefs.saveRepairNotes(notes)
                        }) { Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRed) }
                    }
                }
            }
        }

        item { Text("📂 सेव किए गए AI रिपेयर केस (${cases.size})", fontWeight = FontWeight.Bold, color = ElectricBlue) }
        if (cases.isEmpty()) {
            item { Text("अभी कोई AI केस सेव नहीं है। AI Photo Scanner या Fault Finder से केस सेव करें।", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(cases, key = { it.id }) { c ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(c.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("${c.source} • ${c.timestamp}", fontSize = 11.sp, color = SafeGreen)
                            }
                            IconButton(onClick = {
                                cases = cases.filterNot { it.id == c.id }
                                prefs.saveSavedCases(cases)
                            }) { Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRed) }
                        }
                        Text(c.analysisText.take(350) + if (c.analysisText.length > 350) "..." else "", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun BookmarksAndChecklistSection(
    prefs: AppPreferences,
    lang: AppLanguage,
    onNavigate: (String) -> Unit
) {
    var doneIds by remember { mutableStateOf(prefs.loadChecklistState()) }
    var bookmarks by remember { mutableStateOf(prefs.loadBookmarks()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(bi(lang, "⭐ बुकमार्क्स (${bookmarks.size})", "⭐ Bookmarks (${bookmarks.size})"), fontWeight = FontWeight.Bold, color = ElectricBlue)
        }
        if (bookmarks.isEmpty()) {
            item { Text("अभी कोई बुकमार्क नहीं है। किसी भी कैटेगरी या कंपोनेंट पर बुकमार्क आइकन दबाएं।", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(bookmarks, key = { it.id }) { b ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onNavigate(b.route) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(b.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(b.type, fontSize = 11.sp, color = ElectricBlue)
                        }
                        IconButton(onClick = {
                            bookmarks = bookmarks.filterNot { it.id == b.id }
                            prefs.saveBookmarks(bookmarks)
                        }) { Icon(Icons.Default.Delete, contentDescription = "Remove", tint = DangerRed) }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("✅ सुरक्षित रिपेयर चेकलिस्ट (${doneIds.size}/12)", fontWeight = FontWeight.Bold, color = SafeGreen)
                OutlinedButton(onClick = { doneIds = emptySet(); prefs.saveChecklistState(emptySet()) }) {
                    Text("रीसेट", fontSize = 11.sp)
                }
            }
        }
        items(ExtrasData.repairChecklist, key = { it.id }) { item ->
            val checked = doneIds.contains(item.id)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(
                    modifier = Modifier.fillMaxWidth().clickable {
                        val next = if (checked) doneIds - item.id else doneIds + item.id
                        doneIds = next; prefs.saveChecklistState(next)
                    }.padding(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Checkbox(checked = checked, onCheckedChange = {
                        val next = if (it) doneIds + item.id else doneIds - item.id
                        doneIds = next; prefs.saveChecklistState(next)
                    })
                    Column {
                        Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(item.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun SafetyCenterSection(lang: AppLanguage) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "🛡️ अनिवार्य इलेक्ट्रॉनिक्स सुरक्षा केंद्र", "🛡️ Mandatory Electronics Safety Center"),
                style = MaterialTheme.typography.titleLarge,
                color = DangerRed
            )
            Text(
                "याद रखें: बड़े कैपेसिटर प्लग निकालने के बाद भी जानलेवा चार्ज रखते हैं। खतरनाक हाई-वोल्टेज रिपेयर हमेशा प्रशिक्षित टेक्नीशियन से कराएं।",
                fontSize = 13.sp,
                color = SafetyAmber
            )
        }
        items(ExtrasData.safetyTopics, key = { it.id }) { topic ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.12f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DangerRed.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = DangerRed)
                        Spacer(Modifier.width(8.dp))
                        Text(topic.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = DangerRed)
                    }
                    Text("खतरा स्तर: ${topic.dangerLevel}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SafetyAmber)
                    Text(topic.explanation, fontSize = 13.sp)
                    Text("✔ सुरक्षा नियम: ${topic.rule}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = SafeGreen)
                }
            }
        }
    }
}
