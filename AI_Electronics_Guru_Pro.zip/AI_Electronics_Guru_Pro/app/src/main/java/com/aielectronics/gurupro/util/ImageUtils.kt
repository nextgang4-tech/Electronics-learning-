package com.aielectronics.gurupro.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max

data class CompressedPhoto(
    val uri: Uri,
    val base64Jpeg: String,
    val sizeKb: Int,
    val previewBitmap: Bitmap
)

object ImageUtils {

    fun createCameraImageUri(context: Context): Uri {
        val dir = File(context.cacheDir, "camera_photos").apply { mkdirs() }
        val file = File(dir, "pcb_capture_${System.currentTimeMillis()}.jpg")
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun compressUriForAi(context: Context, uri: Uri, maxDimension: Int = 1280): CompressedPhoto? {
        return runCatching {
            val resolver = context.contentResolver
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOptions)
            }

            var inSampleSize = 1
            val maxSide = max(boundsOptions.outWidth, boundsOptions.outHeight)
            while (maxSide / inSampleSize > maxDimension * 2) {
                inSampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { this.inSampleSize = inSampleSize }
            val rawBitmap = resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            } ?: return null

            val rotated = applyExifRotation(context, uri, rawBitmap)
            val scaled = scaleBitmap(rotated, maxDimension)
            val preview = scaleBitmap(scaled, 480)

            var quality = 84
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            while (baos.size() > 750 * 1024 && quality > 45) {
                baos.reset()
                quality -= 10
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            }

            val bytes = baos.toByteArray()
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            if (scaled != preview && scaled != rawBitmap) scaled.recycle()
            if (rotated != rawBitmap && rotated != preview && rotated != scaled) rotated.recycle()
            if (rawBitmap != preview) rawBitmap.recycle()

            CompressedPhoto(
                uri = uri,
                base64Jpeg = b64,
                sizeKb = max(1, bytes.size / 1024),
                previewBitmap = preview
            )
        }.getOrNull()
    }

    private fun applyExifRotation(context: Context, uri: Uri, bitmap: Bitmap): Bitmap {
        val orientation = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                ExifInterface(input).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bitmap
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun scaleBitmap(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val longest = max(w, h)
        if (longest <= maxDimension) return bitmap
        val ratio = maxDimension.toFloat() / longest.toFloat()
        val newW = max(1, (w * ratio).toInt())
        val newH = max(1, (h * ratio).toInt())
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }
}
