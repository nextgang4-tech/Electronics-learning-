package com.aielectronics.gurupro.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.SavedRepairCase
import com.aielectronics.gurupro.network.AiResult
import com.aielectronics.gurupro.network.GeminiApiClient
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.util.CompressedPhoto
import com.aielectronics.gurupro.util.ImageUtils
import com.aielectronics.gurupro.util.bi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PhotoScannerScreen(
    prefs: AppPreferences,
    lang: AppLanguage,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = prefs.loadSettings()

    var selectedPhotos by remember { mutableStateOf<List<CompressedPhoto>>(emptyList()) }
    var replaceIndex by remember { mutableIntStateOf(-1) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var userNotes by remember { mutableStateOf("") }
    var isCompressing by remember { mutableStateOf(false) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var analysisResult by remember { mutableStateOf<String?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    fun addOrReplaceUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        scope.launch {
            isCompressing = true
            val compressed = withContext(Dispatchers.IO) {
                uris.mapNotNull { ImageUtils.compressUriForAi(context, it) }
            }
            if (replaceIndex in selectedPhotos.indices && compressed.isNotEmpty()) {
                val updated = selectedPhotos.toMutableList()
                updated[replaceIndex] = compressed.first()
                selectedPhotos = updated
                replaceIndex = -1
            } else {
                selectedPhotos = (selectedPhotos + compressed).take(5)
            }
            isCompressing = false
        }
    }

    val multiGalleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 5)
    ) { uris -> addOrReplaceUris(uris) }

    val singleReplaceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) addOrReplaceUris(listOf(uri)) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            addOrReplaceUris(listOf(uri))
        }
        pendingCameraUri = null
    }

    fun launchCameraNow() {
        runCatching {
            val uri = ImageUtils.createCameraImageUri(context)
            pendingCameraUri = uri
            takePictureLauncher.launch(uri)
        }.onFailure {
            Toast.makeText(
                context,
                bi(lang, "कैमरा खोलने में समस्या आई।", "Camera open karne me error aaya."),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchCameraNow()
        } else {
            Toast.makeText(
                context,
                bi(lang, "लाइव फोटो खींचने के लिए कैमरा अनुमति आवश्यक है।", "Live photo ke liye Camera permission zaroori hai."),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "🔍 AI इलेक्ट्रॉनिक्स फोटो स्कैनर", "🔍 AI Electronics Photo Scanner"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = bi(
                    lang,
                    "सर्किट बोर्ड (PCB), चार्जर या किसी कंपोनेंट की साफ़ फोटो लें या गैलरी से चुनें (अधिकतम 5 फोटो)। AI विज़ुअल अवलोकन और संभावित खराबी को अलग-अलग समझाएगा।",
                    "PCB ya component ki clear photo capture karein ya gallery se select karein (max 5 photos)."
                ),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Safety Notice
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SafetyAmber.copy(alpha = 0.14f), RoundedCornerShape(12.dp))
                    .border(1.dp, SafetyAmber.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = SafetyAmber)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = bi(
                        lang,
                        "फोटो खींचने से पहले उपकरण को बिजली से अनप्लग करें। केवल फोटो से कोई भी खराबी 100% पक्की नहीं होती — पुष्टि के लिए सुरक्षित मल्टीमीटर टेस्ट ज़रूरी है।",
                        "Photo lene se pehle device unplug karein. Sirf photo se fault 100% confirm nahi hota."
                    ),
                    fontSize = 12.sp
                )
            }
        }

        // Two Separate Native Buttons: Gallery & Camera
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        replaceIndex = -1
                        multiGalleryLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(bi(lang, "गैलरी से चुनें", "Gallery"), fontSize = 13.sp)
                }

                Button(
                    onClick = {
                        replaceIndex = -1
                        val hasPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.CAMERA
                        ) == PackageManager.PERMISSION_GRANTED
                        if (hasPerm) launchCameraNow()
                        else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = SafeGreen, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(bi(lang, "कैमरा खोलें", "Open Camera"), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (isCompressing) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(bi(lang, "फोटो कंप्रेस हो रही है...", "Photo compress ho rahi hai..."), fontSize = 13.sp)
                }
            }
        }

        // Multi-Photo Preview Carousel with Replace & Remove
        if (selectedPhotos.isNotEmpty()) {
            item {
                Text(
                    text = bi(
                        lang,
                        "चुनी गई फोटो (${selectedPhotos.size}/5) — ऑटो-कंप्रेस्ड:",
                        "Selected Photos (${selectedPhotos.size}/5) — Auto-compressed:"
                    ),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(selectedPhotos) { index, photo ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(
                                modifier = Modifier.width(140.dp).padding(6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box {
                                    Image(
                                        bitmap = photo.previewBitmap.asImageBitmap(),
                                        contentDescription = "Selected PCB photo",
                                        modifier = Modifier
                                            .size(126.dp)
                                            .clip(RoundedCornerShape(10.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    IconButton(
                                        onClick = {
                                            selectedPhotos = selectedPhotos.filterIndexed { i, _ -> i != index }
                                        },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .size(26.dp)
                                            .background(DangerRed, CircleShape)
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "Remove",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("${photo.sizeKb} KB", fontSize = 11.sp, color = SafeGreen)
                                OutlinedButton(
                                    onClick = {
                                        replaceIndex = index
                                        singleReplaceLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(bi(lang, "बदलें", "Replace"), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Optional symptom description
        item {
            OutlinedTextField(
                value = userNotes,
                onValueChange = { userNotes = it },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    Text(bi(lang, "समस्या का विवरण (वैकल्पिक)", "Problem details (Optional)"))
                },
                placeholder = {
                    Text(bi(lang, "जैसे: यह 12V एडॉप्टर अचानक बंद हो गया और हल्की जलने की गंध आई...", "Jaise: 12V adapter band ho gaya..."))
                },
                minLines = 2
            )
        }

        // API key warning if missing
        if (settings.apiKey.isBlank()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = bi(
                                lang,
                                "AI स्कैन के लिए Settings में अपनी Gemini API Key सेव करें।",
                                "AI Scan ke liye Settings me Gemini API Key save karein."
                            ),
                            modifier = Modifier.weight(1f),
                            fontSize = 12.sp
                        )
                        OutlinedButton(onClick = onOpenSettings) {
                            Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Settings", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Analyze Button
        item {
            Button(
                onClick = {
                    errorMsg = null
                    analysisResult = null
                    scope.launch {
                        isAnalyzing = true
                        val res = GeminiApiClient.analyzeElectronicsPhotos(
                            apiKey = settings.apiKey,
                            model = settings.modelName,
                            base64Images = selectedPhotos.map { it.base64Jpeg },
                            userNotes = userNotes,
                            lang = lang
                        )
                        isAnalyzing = false
                        when (res) {
                            is AiResult.Success -> analysisResult = res.data
                            is AiResult.Error -> errorMsg = res.message
                        }
                    }
                },
                enabled = selectedPhotos.isNotEmpty() && !isAnalyzing && !isCompressing,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isAnalyzing) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(10.dp))
                    Text(bi(lang, "AI विश्लेषण कर रहा है...", "AI analyze kar raha hai..."))
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(bi(lang, "AI से PCB और कंपोनेंट विश्लेषण करें", "Analyze Photos with AI"), fontWeight = FontWeight.Bold)
                }
            }
        }

        if (errorMsg != null) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.16f))) {
                    Text(errorMsg.orEmpty(), modifier = Modifier.padding(12.dp), color = DangerRed, fontSize = 13.sp)
                }
            }
        }

        if (analysisResult != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = bi(lang, "AI फोटो विश्लेषण रिपोर्ट", "AI Photo Analysis Report"),
                                fontWeight = FontWeight.Bold,
                                color = ElectricBlue,
                                fontSize = 16.sp
                            )
                            OutlinedButton(
                                onClick = {
                                    val now = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                                    val newCase = SavedRepairCase(
                                        id = "case_${System.currentTimeMillis()}",
                                        title = userNotes.ifBlank { "PCB Photo Scan ($now)" }.take(45),
                                        source = "AI Photo Scanner",
                                        analysisText = analysisResult.orEmpty(),
                                        timestamp = now
                                    )
                                    val existing = prefs.loadSavedCases().toMutableList()
                                    existing.add(0, newCase)
                                    prefs.saveSavedCases(existing)
                                    Toast.makeText(
                                        context,
                                        bi(lang, "रिपेयर केस सेव हो गया!", "Repair case save ho gaya!"),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            ) {
                                Icon(Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(bi(lang, "केस सेव करें", "Save Case"), fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(text = analysisResult.orEmpty(), fontSize = 14.sp, lineHeight = 21.sp)
                    }
                }
            }
        }
    }
}
