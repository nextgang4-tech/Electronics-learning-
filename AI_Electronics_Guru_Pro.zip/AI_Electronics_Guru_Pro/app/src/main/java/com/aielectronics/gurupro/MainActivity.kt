package com.aielectronics.gurupro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.ui.navigation.AppNavHost
import com.aielectronics.gurupro.ui.theme.AIElectronicsGuruTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        val prefs = AppPreferences(applicationContext)

        setContent {
            var settings by remember { mutableStateOf(prefs.loadSettings()) }
            AIElectronicsGuruTheme(themeMode = settings.themeMode) {
                AppNavHost(
                    prefs = prefs,
                    settings = settings,
                    onSettingsUpdated = { updated -> settings = updated }
                )
            }
        }
    }
}
