package com.aielectronics.gurupro.data

import android.content.Context
import android.content.SharedPreferences
import com.aielectronics.gurupro.data.content.ExtrasData
import org.json.JSONArray
import org.json.JSONObject

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ai_electronics_guru_pro_prefs", Context.MODE_PRIVATE)

    fun loadSettings(): AppSettings {
        val langStr = prefs.getString("language", AppLanguage.HINDI.name) ?: AppLanguage.HINDI.name
        val themeStr = prefs.getString("theme_mode", ThemeMode.DARK.name) ?: ThemeMode.DARK.name
        return AppSettings(
            apiKey = prefs.getString("gemini_api_key", "") ?: "",
            modelName = prefs.getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash",
            imageApiModel = prefs.getString("image_api_model", "") ?: "",
            language = runCatching { AppLanguage.valueOf(langStr) }.getOrDefault(AppLanguage.HINDI),
            themeMode = runCatching { ThemeMode.valueOf(themeStr) }.getOrDefault(ThemeMode.DARK)
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString("gemini_api_key", settings.apiKey.trim())
            .putString("gemini_model", settings.modelName.trim().ifEmpty { "gemini-2.5-flash" })
            .putString("image_api_model", settings.imageApiModel.trim())
            .putString("language", settings.language.name)
            .putString("theme_mode", settings.themeMode.name)
            .apply()
    }

    fun loadChatHistory(): List<ChatMessage> {
        val raw = prefs.getString("chat_history", "[]") ?: "[]"
        val list = mutableListOf<ChatMessage>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    ChatMessage(
                        id = obj.optString("id"),
                        isUser = obj.optBoolean("isUser"),
                        text = obj.optString("text"),
                        timestamp = obj.optString("timestamp")
                    )
                )
            }
        }
        return list
    }

    fun saveChatHistory(messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.takeLast(60).forEach { msg ->
            arr.put(
                JSONObject().apply {
                    put("id", msg.id)
                    put("isUser", msg.isUser)
                    put("text", msg.text)
                    put("timestamp", msg.timestamp)
                }
            )
        }
        prefs.edit().putString("chat_history", arr.toString()).apply()
    }

    fun clearChatHistory() {
        prefs.edit().remove("chat_history").apply()
    }

    fun loadCompletedCourseLevels(): Set<Int> {
        val raw = prefs.getString("completed_levels", "") ?: ""
        return raw.split(",").mapNotNull { it.toIntOrNull() }.toSet()
    }

    fun markCourseLevelCompleted(level: Int) {
        val current = loadCompletedCourseLevels().toMutableSet()
        current.add(level)
        prefs.edit().putString("completed_levels", current.joinToString(",")).apply()
    }

    fun loadRepairNotes(): List<RepairNote> {
        val raw = prefs.getString("repair_notes", "[]") ?: "[]"
        val list = mutableListOf<RepairNote>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    RepairNote(
                        id = o.optString("id"),
                        title = o.optString("title"),
                        device = o.optString("device"),
                        content = o.optString("content"),
                        timestamp = o.optString("timestamp")
                    )
                )
            }
        }
        return list
    }

    fun saveRepairNotes(notes: List<RepairNote>) {
        val arr = JSONArray()
        notes.forEach { n ->
            arr.put(
                JSONObject().apply {
                    put("id", n.id)
                    put("title", n.title)
                    put("device", n.device)
                    put("content", n.content)
                    put("timestamp", n.timestamp)
                }
            )
        }
        prefs.edit().putString("repair_notes", arr.toString()).apply()
    }

    fun loadSavedCases(): List<SavedRepairCase> {
        val raw = prefs.getString("saved_cases", "[]") ?: "[]"
        val list = mutableListOf<SavedRepairCase>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    SavedRepairCase(
                        id = o.optString("id"),
                        title = o.optString("title"),
                        source = o.optString("source"),
                        analysisText = o.optString("analysisText"),
                        timestamp = o.optString("timestamp")
                    )
                )
            }
        }
        return list
    }

    fun saveSavedCases(cases: List<SavedRepairCase>) {
        val arr = JSONArray()
        cases.forEach { c ->
            arr.put(
                JSONObject().apply {
                    put("id", c.id)
                    put("title", c.title)
                    put("source", c.source)
                    put("analysisText", c.analysisText)
                    put("timestamp", c.timestamp)
                }
            )
        }
        prefs.edit().putString("saved_cases", arr.toString()).apply()
    }

    fun loadBookmarks(): List<BookmarkItem> {
        val raw = prefs.getString("bookmarks", "[]") ?: "[]"
        val list = mutableListOf<BookmarkItem>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    BookmarkItem(
                        id = o.optString("id"),
                        type = o.optString("type"),
                        title = o.optString("title"),
                        route = o.optString("route")
                    )
                )
            }
        }
        return list
    }

    fun saveBookmarks(items: List<BookmarkItem>) {
        val arr = JSONArray()
        items.forEach { b ->
            arr.put(
                JSONObject().apply {
                    put("id", b.id)
                    put("type", b.type)
                    put("title", b.title)
                    put("route", b.route)
                }
            )
        }
        prefs.edit().putString("bookmarks", arr.toString()).apply()
    }

    fun loadSearchHistory(): List<String> {
        val raw = prefs.getString("search_history", "[]") ?: "[]"
        val list = mutableListOf<String>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                list.add(arr.getString(i))
            }
        }
        return list
    }

    fun addSearchHistory(query: String) {
        val clean = query.trim()
        if (clean.length < 2) return
        val current = loadSearchHistory().toMutableList()
        current.removeAll { it.equals(clean, ignoreCase = true) }
        current.add(0, clean)
        val arr = JSONArray()
        current.take(15).forEach { arr.put(it) }
        prefs.edit().putString("search_history", arr.toString()).apply()
    }

    fun clearSearchHistory() {
        prefs.edit().remove("search_history").apply()
    }

    fun loadComponentPrices(): List<ComponentPriceItem> {
        val raw = prefs.getString("component_prices", null)
        if (raw.isNullOrBlank()) return ExtrasData.defaultComponentPrices
        val list = mutableListOf<ComponentPriceItem>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    ComponentPriceItem(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        specs = o.optString("specs"),
                        estimatedPriceInr = o.optInt("price", 10)
                    )
                )
            }
        }
        return if (list.isEmpty()) ExtrasData.defaultComponentPrices else list
    }

    fun saveComponentPrices(items: List<ComponentPriceItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("specs", item.specs)
                    put("price", item.estimatedPriceInr)
                }
            )
        }
        prefs.edit().putString("component_prices", arr.toString()).apply()
    }

    fun loadChecklistState(): Set<String> {
        val raw = prefs.getString("checklist_done", "") ?: ""
        return raw.split(",").filter { it.isNotBlank() }.toSet()
    }

    fun saveChecklistState(doneIds: Set<String>) {
        prefs.edit().putString("checklist_done", doneIds.joinToString(",")).apply()
    }
}
