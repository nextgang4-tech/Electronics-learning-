package com.aielectronics.gurupro.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.content.MultimeterData
import com.aielectronics.gurupro.ui.components.MultimeterDiagramCard
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.util.bi

@Composable
fun MultimeterScreen(lang: AppLanguage) {
    var selected by remember { mutableStateOf(MultimeterData.allLessons.first()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "📟 मल्टीमीटर मास्टर ट्रेनर", "📟 Multimeter Master Trainer"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
        }

        // Mandatory Safety Rule Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "⚠️ ${MultimeterData.mandatorySafetyBanner}",
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DangerRed, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // 10 Measurement Mode Chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(MultimeterData.allLessons) { lesson ->
                    FilterChip(
                        selected = selected.id == lesson.id,
                        onClick = { selected = lesson },
                        label = { Text(lesson.titleHi, fontSize = 12.sp) }
                    )
                }
            }
        }

        // Interactive Canvas Multimeter Diagram
        item {
            MultimeterDiagramCard(diagramType = selected.diagramType)
        }

        // Specific Safety Rule for this measurement
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selected.isHighVoltageWarning) DangerRed.copy(alpha = 0.15f) else SafetyAmber.copy(alpha = 0.14f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (selected.isHighVoltageWarning) "⚠️ हाई-वोल्टेज सावधानी" else "🛡️ इस टेस्ट का सुरक्षा नियम",
                        fontWeight = FontWeight.Bold,
                        color = if (selected.isHighVoltageWarning) DangerRed else SafetyAmber,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(selected.safetyRule, fontSize = 13.sp)
                }
            }
        }

        // All 6 Required Steps
        item { DetailSectionCard("1️⃣ कौन सी डायल सेटिंग चुनें (Dial Setting)", selected.dialSetting) }
        item { DetailSectionCard("2️⃣ कौन सा सॉकेट उपयोग करें (Socket to Use)", selected.socketToUse) }
        item { DetailSectionCard("3️⃣ काला प्रोब कहाँ लगाएं (Black Probe)", selected.blackProbePlacement) }
        item { DetailSectionCard("4️⃣ लाल प्रोब कहाँ लगाएं (Red Probe)", selected.redProbePlacement) }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SafeGreen.copy(alpha = 0.14f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("5️⃣ अपेक्षित रीडिंग (Expected Reading)", fontWeight = FontWeight.Bold, color = SafeGreen, fontSize = 15.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(selected.expectedReading, fontSize = 14.sp)
                }
            }
        }
        item { DetailBulletCard("6️⃣ अलग-अलग रीडिंग का मतलब (What Readings Mean)", selected.readingMeanings) }
    }
}
