package com.aielectronics.gurupro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.content.SolderingData
import com.aielectronics.gurupro.ui.components.SolderingDiagramCard
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.util.bi

@Composable
fun SolderingScreen(lang: AppLanguage) {
    var selected by remember { mutableStateOf(SolderingData.allLessons.first()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "🔥 सोल्डरिंग मास्टर ट्रेनर", "🔥 Soldering Master Trainer"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(SolderingData.allLessons) { lesson ->
                    FilterChip(
                        selected = selected.id == lesson.id,
                        onClick = { selected = lesson },
                        label = { Text(lesson.titleHi, fontSize = 12.sp) }
                    )
                }
            }
        }

        item {
            SolderingDiagramCard(diagramType = selected.diagramType)
        }

        item {
            DetailSectionCard(selected.titleHi, selected.summary)
        }

        item {
            DetailBulletCard(bi(lang, "📋 स्टेप-बाय-स्टेप तरीका", "📋 Step-by-Step Method"), selected.steps)
        }

        item {
            DetailBulletCard(bi(lang, "💡 प्रो टिप्स", "💡 Pro Tips"), selected.proTips)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SafetyAmber.copy(alpha = 0.14f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("⚠️ सुरक्षा नोट", fontWeight = FontWeight.Bold, color = SafetyAmber, fontSize = 14.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(selected.safetyNote, fontSize = 13.sp)
                }
            }
        }
    }
}
