package com.aielectronics.gurupro.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

sealed class AiResult<out T> {
    data class Success<T>(val data: T) : AiResult<T>()
    data class Error(val message: String) : AiResult<Nothing>()
}

object GeminiApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun buildEndpoint(model: String, apiKey: String): String {
        val cleanModel = model.trim().ifEmpty { "gemini-2.5-flash" }
        return "https://generativelanguage.googleapis.com/v1beta/models/$cleanModel:generateContent?key=${apiKey.trim()}"
    }

    suspend fun testConnection(apiKey: String, model: String, lang: AppLanguage): AiResult<String> {
        if (apiKey.isBlank()) {
            return AiResult.Error(
                if (lang == AppLanguage.HINDI)
                    "कृपया पहले सेटिंग्स में अपनी Gemini API Key दर्ज करें।"
                else
                    "Pehle Settings me apni Gemini API Key enter karein."
            )
        }
        val payload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", "Reply with OK only."))
                    })
                })
            })
        }
        return executeGenerateContent(apiKey, model, payload, lang)
    }

    suspend fun analyzeElectronicsPhotos(
        apiKey: String,
        model: String,
        base64Images: List<String>,
        userNotes: String,
        lang: AppLanguage
    ): AiResult<String> {
        if (apiKey.isBlank()) {
            return AiResult.Error(
                if (lang == AppLanguage.HINDI)
                    "Gemini API Key सेट नहीं है। कृपया Settings में जाकर अपनी API Key सेव करें।"
                else
                    "Gemini API Key set nahi hai. Settings me jaakar apni API Key save karein."
            )
        }
        if (base64Images.isEmpty()) {
            return AiResult.Error(
                if (lang == AppLanguage.HINDI)
                    "कृपया कम से कम एक फोटो चुनें या कैमरे से खींचें।"
                else
                    "Kam se kam ek photo select ya capture karein."
            )
        }

        val langRule = if (lang == AppLanguage.HINDI) {
            "जवाब सरल और स्पष्ट हिंदी (Devanagari) में दें, तकनीकी शब्दों को कोष्ठक में अंग्रेज़ी में लिखें।"
        } else {
            "Jawab aasan aur clear Hinglish me dein jo ek complete beginner samajh sake."
        }

        val systemPrompt = """
            You are AI Electronics Guru Pro, a senior electronics repair engineer and patient Hindi teacher for beginners.
            $langRule
            CRITICAL SAFETY & ACCURACY RULES:
            1. ALWAYS clearly separate:
               - **पक्के विज़ुअल अवलोकन (Confirmed Visual Observations)**: Only what is actually visible in the photo(s).
               - **संभावित खराबियां / अनुमान (Possible Diagnoses — फोटो से 100% पक्का नहीं)**: Never claim a fault is confirmed from a photo alone; always state that physical/multimeter testing is needed to confirm.
            2. Cover these exact sections clearly with headings:
               1) डिवाइस / बोर्ड की पहचान (Device / PCB Identification)
               2) दिखाई देने वाले कंपोनेंट्स और मार्किंग (Visible Components & PCB Markings + Function of each)
               3) पक्के विज़ुअल अवलोकन (Confirmed Visual Observations: burn marks, damaged tracks, corrosion, swollen capacitors, loose solder joints — or clearly state if not clearly visible)
               4) संभावित खराबियां (Possible Faults — केवल अनुमान, पुष्टि के लिए टेस्ट ज़रूरी)
               5) आगे क्या चेक करें और सुरक्षित मल्टीमीटर टेस्टिंग (Next Checks & Safe Multimeter Testing — NEVER instruct resistance/continuity/diode testing on energized circuits; NEVER instruct current mode across a power source)
               6) संभावित रिप्लेसमेंट कंपोनेंट्स और स्पेसिफिकेशन (Possible Replacement Parts — do not invent unreadable part numbers; state "बोर्ड पर लिखा नंबर पढ़कर ही बदलें" if blurry)
               7) सरल रिपेयर स्टेप्स और सुरक्षा चेतावनी (Beginner Repair Steps & High-Voltage Safety Warning — for 230V mains, SMPS primary, microwave HV, CRT, inverter/UPS, HV capacitors, or lithium packs, warn strongly to unplug, note capacitors hold lethal charge, and advise a qualified technician).
        """.trimIndent()

        val parts = JSONArray().apply {
            val promptText = buildString {
                append("कृपया अपलोड की गई इलेक्ट्रॉनिक्स / PCB फोटो का पूरा विश्लेषण करें।")
                if (userNotes.isNotBlank()) {
                    append("\nयूज़र का विवरण / समस्या: $userNotes")
                }
            }
            put(JSONObject().put("text", promptText))
            base64Images.forEach { b64 ->
                put(JSONObject().apply {
                    put("inline_data", JSONObject().apply {
                        put("mime_type", "image/jpeg")
                        put("data", b64)
                    })
                })
            }
        }

        val payload = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", parts)
            }))
        }

        return executeGenerateContent(apiKey, model, payload, lang)
    }

    suspend fun sendRepairChat(
        apiKey: String,
        model: String,
        history: List<ChatMessage>,
        newUserMessage: String,
        lang: AppLanguage
    ): AiResult<String> {
        if (apiKey.isBlank()) {
            return AiResult.Error(
                if (lang == AppLanguage.HINDI)
                    "कृपया पहले Settings में अपनी Gemini API Key सेव करें।"
                else
                    "Pehle Settings me apni Gemini API Key save karein."
            )
        }

        val langRule = if (lang == AppLanguage.HINDI) {
            "हमेशा सरल हिंदी में उत्तर दें।"
        } else {
            "Hamesha simple aur clear Hinglish me jawab dein."
        }

        val systemPrompt = """
            You are AI Electronics Guru Pro — a friendly, safety-first electronics repair mentor for complete beginners in India.
            $langRule
            RULES:
            - Ask 2–3 relevant follow-up diagnostic questions when needed and guide the user step by step.
            - Prioritize safe visual checks first (unplugged).
            - Never invent circuit values or measurements the user hasn't provided.
            - NEVER guide an untrained beginner to perform live 230V AC mains, SMPS primary, microwave HV, CRT, or inverter high-voltage repairs. Give safe theory and advise a qualified technician for hazardous live circuits.
            - Remind beginners never to use Resistance, Continuity, or Diode mode on a powered circuit, and never put multimeter current probes directly across a voltage source.
        """.trimIndent()

        val contents = JSONArray()
        history.takeLast(12).forEach { msg ->
            contents.put(JSONObject().apply {
                put("role", if (msg.isUser) "user" else "model")
                put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
            })
        }
        contents.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", newUserMessage)))
        })

        val payload = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            })
            put("contents", contents)
        }

        return executeGenerateContent(apiKey, model, payload, lang)
    }

    suspend fun runFaultFinder(
        apiKey: String,
        model: String,
        appliance: String,
        symptoms: String,
        measurements: String,
        base64Images: List<String>,
        lang: AppLanguage
    ): AiResult<String> {
        if (apiKey.isBlank()) {
            return AiResult.Error(
                if (lang == AppLanguage.HINDI)
                    "AI Fault Finder के लिए Settings में Gemini API Key डालें।"
                else
                    "AI Fault Finder ke liye Settings me Gemini API Key dalein."
            )
        }

        val langRule = if (lang == AppLanguage.HINDI) {
            "पूरा उत्तर सरल हिंदी में दें।"
        } else {
            "Pura jawab simple Hinglish me dein."
        }

        val systemPrompt = """
            You are an interactive AI Fault Finder for beginner electronics learners.
            $langRule
            STRICT WORKFLOW:
            1. लक्षणों की समझ (Understand Symptoms) + ज़रूरी Follow-up प्रश्न पूछें।
            2. संभावित कारण (Possible Causes — confirmed नहीं, केवल संभावना)।
            3. सुरक्षित विज़ुअल जांच (Safe Visual Inspection — डिवाइस को अनप्लग रखकर)।
            4. ज़रूरी मल्टीमीटर माप (Relevant Safe Measurements to take next — कभी भी चालू सर्किट पर Resistance/Continuity/Diode न बताएं)।
            5. यूज़र द्वारा दिए गए माप का अर्थ (Explain what measurements mean — यदि यूज़र ने माप नहीं दिया है, तो काल्पनिक माप न बनाएं)।
            6. अगला डायग्नोस्टिक कदम (Next Safe Diagnostic Step)।
            7. कब क्वालिफाइड टेक्नीशियन को बुलाएं (When a qualified technician is required — हाई वोल्टेज, 230V, माइक्रोवेव, इन्वर्टर, SMPS प्राइमरी, चार्ज्ड कैपेसिटर के लिए सख्त चेतावनी)।
            NEVER invent measurements, component values, or circuit specifications.
        """.trimIndent()

        val parts = JSONArray().apply {
            val query = buildString {
                append("उपकरण (Appliance): $appliance\n")
                append("लक्षण / समस्या (Symptoms): $symptoms\n")
                if (measurements.isNotBlank()) {
                    append("यूज़र द्वारा लिए गए माप (User Measurements): $measurements\n")
                } else {
                    append("यूज़र ने अभी कोई मल्टीमीटर माप नहीं दिया है।\n")
                }
            }
            put(JSONObject().put("text", query))
            base64Images.forEach { b64 ->
                put(JSONObject().apply {
                    put("inline_data", JSONObject().apply {
                        put("mime_type", "image/jpeg")
                        put("data", b64)
                    })
                })
            }
        }

        val payload = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", parts)
            }))
        }

        return executeGenerateContent(apiKey, model, payload, lang)
    }

    suspend fun generateEducationalDiagram(
        apiKey: String,
        imageModel: String,
        prompt: String,
        lang: AppLanguage
    ): AiResult<Bitmap> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || imageModel.isBlank()) {
            return@withContext AiResult.Error(
                if (lang == AppLanguage.HINDI)
                    "इमेज जनरेशन API कॉन्फ़िगर नहीं है। Settings में Gemini API Key और समर्थित Image Model (जैसे imagen-3.0-generate-002) सेट करें।"
                else
                    "Image generation API configured nahi hai. Settings me Gemini API Key aur supported Image Model (jaise imagen-3.0-generate-002) set karein."
            )
        }

        val cleanModel = imageModel.trim()
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$cleanModel:predict?key=${apiKey.trim()}"
        val payload = JSONObject().apply {
            put("instances", JSONArray().put(JSONObject().apply {
                put("prompt", "Clean educational electronics schematic diagram on dark navy blueprint background with crisp electric blue lines, clearly drawn for beginners: $prompt")
            }))
            put("parameters", JSONObject().apply {
                put("sampleCount", 1)
            })
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AiResult.Error(mapHttpError(response.code, bodyStr, lang))
                }
                val json = JSONObject(bodyStr)
                val predictions = json.optJSONArray("predictions")
                val b64 = predictions?.optJSONObject(0)?.optString("bytesBase64Encoded").orEmpty()
                if (b64.isBlank()) {
                    return@withContext AiResult.Error(
                        if (lang == AppLanguage.HINDI)
                            "API से इमेज डेटा प्राप्त नहीं हुआ। कृपया जांचें कि आपका API प्लान इस इमेज मॉडल को सपोर्ट करता है।"
                        else
                            "API se image data nahi mila. Check karein ki aapka API plan is image model ko support karta hai."
                    )
                }
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: return@withContext AiResult.Error("Image decode failed.")
                AiResult.Success(bmp)
            }
        } catch (e: Exception) {
            AiResult.Error(mapException(e, lang))
        }
    }

    private suspend fun executeGenerateContent(
        apiKey: String,
        model: String,
        payload: JSONObject,
        lang: AppLanguage
    ): AiResult<String> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(buildEndpoint(model, apiKey))
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AiResult.Error(mapHttpError(response.code, bodyStr, lang))
                }
                val json = JSONObject(bodyStr)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    return@withContext AiResult.Error(
                        if (lang == AppLanguage.HINDI)
                            "AI से कोई उत्तर प्राप्त नहीं हुआ। कृपया थोड़ा अलग प्रश्न या साफ़ फोटो के साथ प्रयास करें।"
                        else
                            "AI se koi jawab nahi mila. Kripya dobara try karein."
                    )
                }
                val parts = candidates.getJSONObject(0)
                    .optJSONObject("content")
                    ?.optJSONArray("parts")
                val sb = StringBuilder()
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val t = parts.getJSONObject(i).optString("text", "")
                        if (t.isNotEmpty()) sb.append(t)
                    }
                }
                val finalText = sb.toString().trim()
                if (finalText.isEmpty()) {
                    AiResult.Error("Empty response from Gemini API.")
                } else {
                    AiResult.Success(finalText)
                }
            }
        } catch (e: Exception) {
            AiResult.Error(mapException(e, lang))
        }
    }

    private fun mapHttpError(code: Int, body: String, lang: AppLanguage): String {
        val apiMsg = runCatching {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        }.getOrDefault("")

        return when (code) {
            400 -> if (lang == AppLanguage.HINDI)
                "अमान्य अनुरोध या API Key (400): $apiMsg"
            else
                "Invalid request ya API Key (400): $apiMsg"

            401, 403 -> if (lang == AppLanguage.HINDI)
                "API Key गलत है या अनुमति नहीं है ($code)। Settings में जाकर सही Gemini API Key डालें।"
            else
                "API Key galat hai ya permission nahi hai ($code). Settings me sahi key dalein."

            404 -> if (lang == AppLanguage.HINDI)
                "चुना गया मॉडल उपलब्ध नहीं है (404)। Settings में 'gemini-2.5-flash' चुनें।"
            else
                "Selected model available nahi hai (404). Settings me 'gemini-2.5-flash' select karein."

            429 -> if (lang == AppLanguage.HINDI)
                "रेट लिमिट या API कोटा पूरा हो गया है (429)। कृपया कुछ सेकंड बाद दोबारा प्रयास करें या अपना Gemini कोटा जांचें।"
            else
                "Rate limit ya API quota exceed ho gaya hai (429). Kuch second baad try karein ya quota check karein."

            else -> if (lang == AppLanguage.HINDI)
                "सर्वर त्रुटि ($code): ${apiMsg.ifBlank { "कृपया बाद में प्रयास करें।" }}"
            else
                "Server error ($code): ${apiMsg.ifBlank { "Baad me try karein." }}"
        }
    }

    private fun mapException(e: Exception, lang: AppLanguage): String {
        return when (e) {
            is UnknownHostException -> if (lang == AppLanguage.HINDI)
                "इंटरनेट कनेक्शन नहीं है। कृपया मोबाइल डेटा या Wi-Fi चालू करें।"
            else
                "Internet connection nahi hai. Mobile data ya Wi-Fi check karein."

            is SocketTimeoutException -> if (lang == AppLanguage.HINDI)
                "कनेक्शन टाइमआउट हो गया। नेटवर्क धीमा है, कृपया दोबारा प्रयास करें।"
            else
                "Connection timeout ho gaya. Network slow hai, dobara try karein."

            is IOException -> if (lang == AppLanguage.HINDI)
                "नेटवर्क त्रुटि: ${e.localizedMessage ?: "कनेक्शन विफल"}"
            else
                "Network error: ${e.localizedMessage ?: "Connection failed"}"

            else -> "Error: ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }
}
