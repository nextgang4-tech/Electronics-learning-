package com.aielectronics.gurupro.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.ui.theme.SkyCyan
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MultimeterDiagramCard(diagramType: String) {
    val (dialAngleDeg, lcdText, modeLabel) = when (diagramType) {
        "dcv", "battery" -> Triple(-135f, "05.02 V", "DCV 20V")
        "acv" -> Triple(-45f, "230.4 V~", "ACV 750V")
        "ohm" -> Triple(135f, "1.00 kΩ", "Ω 20k")
        "continuity", "fuse", "wire" -> Triple(90f, "001 🔊", "BEEP / Ω")
        "diode", "transistor" -> Triple(65f, "0.612 ▶|", "DIODE")
        "capacitor" -> Triple(20f, "470 uF", "CAP uF")
        else -> Triple(-135f, "00.00", "DCV")
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF071122), RoundedCornerShape(14.dp))
            .border(1.dp, ElectricBlue.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "मल्टीमीटर डायल और प्रोब डायग्राम ($modeLabel)",
            color = ElectricBlue,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(185.dp)
                .padding(top = 8.dp)
        ) {
            val w = size.width
            val h = size.height
            val meterW = w * 0.46f
            val meterX = (w - meterW) / 2f

            // Meter body
            drawRoundRect(
                color = Color(0xFF1E293B),
                topLeft = Offset(meterX, 6f),
                size = Size(meterW, h - 12f),
                cornerRadius = CornerRadius(18f, 18f)
            )
            drawRoundRect(
                color = ElectricBlue.copy(alpha = 0.7f),
                topLeft = Offset(meterX, 6f),
                size = Size(meterW, h - 12f),
                cornerRadius = CornerRadius(18f, 18f),
                style = Stroke(width = 2.5f)
            )

            // LCD screen
            drawRoundRect(
                color = Color(0xFF0F3D2E),
                topLeft = Offset(meterX + 14f, 18f),
                size = Size(meterW - 28f, 38f),
                cornerRadius = CornerRadius(8f, 8f)
            )

            // Rotary dial
            val dialCenter = Offset(w / 2f, h * 0.56f)
            val dialR = (h * 0.21f).coerceAtMost(meterW * 0.30f)
            drawCircle(
                color = Color(0xFF0B192E),
                radius = dialR + 7f,
                center = dialCenter,
                style = Stroke(width = 2f)
            )
            drawCircle(
                color = Color(0xFF334155),
                radius = dialR,
                center = dialCenter
            )
            val rad = dialAngleDeg * PI.toFloat() / 180f
            val pointerEnd = Offset(
                dialCenter.x + cos(rad) * (dialR - 3f),
                dialCenter.y + sin(rad) * (dialR - 3f)
            )
            drawLine(
                color = ElectricBlue,
                start = dialCenter,
                end = pointerEnd,
                strokeWidth = 6f,
                cap = StrokeCap.Round
            )
            drawCircle(color = ElectricBlue, radius = 5f, center = pointerEnd)

            // 3 Sockets at bottom: 10A (unused), VΩmA (Red), COM (Black)
            val sockY = h - 26f
            val sock10A = Offset(meterX + meterW * 0.22f, sockY)
            val sockRed = Offset(meterX + meterW * 0.52f, sockY)
            val sockCom = Offset(meterX + meterW * 0.80f, sockY)

            drawCircle(color = Color(0xFF64748B), radius = 8f, center = sock10A, style = Stroke(2f))
            drawCircle(color = DangerRed, radius = 9f, center = sockRed)
            drawCircle(color = Color(0xFF020617), radius = 9f, center = sockCom)
            drawCircle(color = Color.White.copy(alpha = 0.8f), radius = 9f, center = sockCom, style = Stroke(2f))

            // Red probe wire to right
            val redPath = Path().apply {
                moveTo(sockRed.x, sockRed.y + 8f)
                cubicTo(sockRed.x + 20f, h + 10f, w * 0.78f, h * 0.8f, w * 0.88f, h * 0.45f)
            }
            drawPath(redPath, color = DangerRed, style = Stroke(width = 4f, cap = StrokeCap.Round))
            // Red probe tip
            drawLine(
                color = Color(0xFFE2E8F0),
                start = Offset(w * 0.88f, h * 0.45f),
                end = Offset(w * 0.92f, h * 0.30f),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )

            // Black probe wire to left
            val blackPath = Path().apply {
                moveTo(sockCom.x, sockCom.y + 8f)
                cubicTo(sockCom.x - 10f, h + 14f, w * 0.22f, h * 0.85f, w * 0.12f, h * 0.45f)
            }
            drawPath(blackPath, color = Color(0xFF94A3B8), style = Stroke(width = 4f, cap = StrokeCap.Round))
            drawLine(
                color = Color(0xFFE2E8F0),
                start = Offset(w * 0.12f, h * 0.45f),
                end = Offset(w * 0.08f, h * 0.30f),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )
        }
        Text(
            text = "LCD: $lcdText  |  ⚫ COM (काला)  |  🔴 VΩmA (लाल)",
            color = SafeGreen,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun ComponentSymbolDiagram(diagramType: String, label: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF071122), RoundedCornerShape(12.dp))
            .border(1.dp, SkyCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(92.dp)
        ) {
            val w = size.width
            val h = size.height
            val cy = h / 2f
            val cx = w / 2f
            val lineCol = ElectricBlue
            val stroke = Stroke(width = 4f, cap = StrokeCap.Round)

            when (diagramType) {
                "resistor" -> {
                    drawLine(lineCol, Offset(w * 0.15f, cy), Offset(w * 0.30f, cy), 4f)
                    val p = Path().apply {
                        moveTo(w * 0.30f, cy)
                        lineTo(w * 0.35f, cy - 18f)
                        lineTo(w * 0.43f, cy + 18f)
                        lineTo(w * 0.51f, cy - 18f)
                        lineTo(w * 0.59f, cy + 18f)
                        lineTo(w * 0.67f, cy - 18f)
                        lineTo(w * 0.70f, cy)
                    }
                    drawPath(p, SafetyAmber, style = stroke)
                    drawLine(lineCol, Offset(w * 0.70f, cy), Offset(w * 0.85f, cy), 4f)
                }

                "capacitor", "ceramic_cap", "electrolytic_cap" -> {
                    drawLine(lineCol, Offset(w * 0.18f, cy), Offset(cx - 12f, cy), 4f)
                    drawLine(SkyCyan, Offset(cx - 12f, cy - 26f), Offset(cx - 12f, cy + 26f), 5f)
                    if (diagramType == "electrolytic_cap") {
                        // Curved negative plate + plus sign
                        val p = Path().apply {
                            moveTo(cx + 16f, cy - 26f)
                            quadraticTo(cx + 4f, cy, cx + 16f, cy + 26f)
                        }
                        drawPath(p, SafetyAmber, style = Stroke(width = 5f))
                        // + sign
                        drawLine(SafeGreen, Offset(cx - 32f, cy - 18f), Offset(cx - 20f, cy - 18f), 3f)
                        drawLine(SafeGreen, Offset(cx - 26f, cy - 24f), Offset(cx - 26f, cy - 12f), 3f)
                    } else {
                        drawLine(SkyCyan, Offset(cx + 12f, cy - 26f), Offset(cx + 12f, cy + 26f), 5f)
                    }
                    drawLine(lineCol, Offset(cx + 12f, cy), Offset(w * 0.82f, cy), 4f)
                }

                "diode", "zener", "led" -> {
                    drawLine(lineCol, Offset(w * 0.18f, cy), Offset(cx - 18f, cy), 4f)
                    val tri = Path().apply {
                        moveTo(cx - 18f, cy - 20f)
                        lineTo(cx - 18f, cy + 20f)
                        lineTo(cx + 16f, cy)
                        close()
                    }
                    drawPath(tri, color = ElectricBlue, style = Stroke(4f))
                    drawLine(SafetyAmber, Offset(cx + 18f, cy - 22f), Offset(cx + 18f, cy + 22f), 5f)
                    if (diagramType == "zener") {
                        drawLine(SafetyAmber, Offset(cx + 18f, cy - 22f), Offset(cx + 28f, cy - 28f), 4f)
                        drawLine(SafetyAmber, Offset(cx + 18f, cy + 22f), Offset(cx + 8f, cy + 28f), 4f)
                    }
                    if (diagramType == "led") {
                        drawLine(SafeGreen, Offset(cx - 2f, cy - 22f), Offset(cx + 12f, cy - 38f), 3f)
                        drawLine(SafeGreen, Offset(cx + 12f, cy - 20f), Offset(cx + 26f, cy - 36f), 3f)
                    }
                    drawLine(lineCol, Offset(cx + 18f, cy), Offset(w * 0.82f, cy), 4f)
                }

                "transistor", "mosfet" -> {
                    drawCircle(SkyCyan.copy(alpha = 0.5f), radius = 34f, center = Offset(cx, cy), style = Stroke(3f))
                    // Base/Gate
                    drawLine(lineCol, Offset(w * 0.20f, cy), Offset(cx - 12f, cy), 4f)
                    drawLine(SafetyAmber, Offset(cx - 12f, cy - 20f), Offset(cx - 12f, cy + 20f), 5f)
                    // Collector / Drain
                    drawLine(lineCol, Offset(cx - 10f, cy - 10f), Offset(cx + 20f, cy - 26f), 4f)
                    drawLine(lineCol, Offset(cx + 20f, cy - 26f), Offset(cx + 20f, cy - 40f), 4f)
                    // Emitter / Source
                    drawLine(SafeGreen, Offset(cx - 10f, cy + 10f), Offset(cx + 20f, cy + 26f), 4f)
                    drawLine(SafeGreen, Offset(cx + 20f, cy + 26f), Offset(cx + 20f, cy + 40f), 4f)
                }

                "ic", "regulator" -> {
                    val boxW = 96f
                    val boxH = 54f
                    drawRoundRect(
                        color = Color(0xFF172554),
                        topLeft = Offset(cx - boxW / 2f, cy - boxH / 2f),
                        size = Size(boxW, boxH),
                        cornerRadius = CornerRadius(8f, 8f)
                    )
                    drawRoundRect(
                        color = ElectricBlue,
                        topLeft = Offset(cx - boxW / 2f, cy - boxH / 2f),
                        size = Size(boxW, boxH),
                        cornerRadius = CornerRadius(8f, 8f),
                        style = Stroke(3f)
                    )
                    // Pin 1 notch dot
                    drawCircle(SafetyAmber, radius = 4f, center = Offset(cx - boxW / 2f + 12f, cy - boxH / 2f + 12f))
                    val pinCount = if (diagramType == "regulator") 3 else 4
                    for (i in 0 until pinCount) {
                        val px = cx - boxW / 2f + (boxW / (pinCount + 1)) * (i + 1)
                        drawLine(SkyCyan, Offset(px, cy + boxH / 2f), Offset(px, cy + boxH / 2f + 14f), 4f)
                        if (diagramType == "ic") {
                            drawLine(SkyCyan, Offset(px, cy - boxH / 2f), Offset(px, cy - boxH / 2f - 14f), 4f)
                        }
                    }
                }

                "inductor", "transformer" -> {
                    drawLine(lineCol, Offset(w * 0.16f, cy), Offset(cx - 42f, cy), 4f)
                    for (i in 0..3) {
                        drawArc(
                            color = SafetyAmber,
                            startAngle = 180f,
                            sweepAngle = 180f,
                            useCenter = false,
                            topLeft = Offset(cx - 42f + i * 21f, cy - 16f),
                            size = Size(21f, 32f),
                            style = Stroke(4f)
                        )
                    }
                    drawLine(lineCol, Offset(cx + 42f, cy), Offset(w * 0.84f, cy), 4f)
                    if (diagramType == "transformer") {
                        drawLine(SkyCyan, Offset(cx - 42f, cy + 16f), Offset(cx + 42f, cy + 16f), 3f)
                        drawLine(SkyCyan, Offset(cx - 42f, cy + 23f), Offset(cx + 42f, cy + 23f), 3f)
                    }
                }

                "fuse" -> {
                    drawLine(lineCol, Offset(w * 0.16f, cy), Offset(cx - 34f, cy), 4f)
                    drawRect(
                        color = SafetyAmber,
                        topLeft = Offset(cx - 34f, cy - 14f),
                        size = Size(68f, 28f),
                        style = Stroke(3.5f)
                    )
                    drawLine(ElectricBlue, Offset(cx - 34f, cy), Offset(cx + 34f, cy), 3.5f)
                    drawLine(lineCol, Offset(cx + 34f, cy), Offset(w * 0.84f, cy), 4f)
                }

                else -> {
                    // Relay / Switch / Connector / Sensor generic clean symbol
                    drawLine(lineCol, Offset(w * 0.18f, cy), Offset(cx - 24f, cy), 4f)
                    drawCircle(SafeGreen, radius = 6f, center = Offset(cx - 24f, cy))
                    drawLine(SafetyAmber, Offset(cx - 24f, cy), Offset(cx + 22f, cy - 22f), 4.5f)
                    drawCircle(SafeGreen, radius = 6f, center = Offset(cx + 24f, cy))
                    drawLine(lineCol, Offset(cx + 24f, cy), Offset(w * 0.82f, cy), 4f)
                }
            }
        }
        Text(
            text = label,
            color = SkyCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun SolderingDiagramCard(diagramType: String) {
    val caption = when (diagramType) {
        "joint" -> "45° सोल्डरिंग आयरन टिप + चमकदार ज्वालामुखी (Volcano) जॉइंट"
        "cold_joint" -> "बाएं: सही चमकदार जॉइंट (✔)  |  दाएं: खराब कोल्ड/गोल जॉइंट (✘)"
        "track" -> "टूटा कॉपर ट्रैक → इनेमल्ड जम्पर वायर से सुरक्षित जुड़ाव"
        "pump", "wick", "desolder" -> "गर्म टिप से सोल्डर पिघलाएं → पंप/विक से साफ करें → पिन निकालें"
        else -> "300°C–350°C टिप + 63/37 रोसिन सोल्डर वायर"
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF071122), RoundedCornerShape(12.dp))
            .border(1.dp, SafetyAmber.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(105.dp)
        ) {
            val w = size.width
            val h = size.height
            // PCB green base
            drawRect(
                color = Color(0xFF065F46),
                topLeft = Offset(w * 0.10f, h * 0.68f),
                size = Size(w * 0.80f, 18f)
            )
            // Copper pad
            drawRect(
                color = SafetyAmber,
                topLeft = Offset(w * 0.40f, h * 0.64f),
                size = Size(w * 0.20f, 6f)
            )
            // Component lead vertical
            drawLine(
                color = Color(0xFFE2E8F0),
                start = Offset(w * 0.50f, h * 0.15f),
                end = Offset(w * 0.50f, h * 0.90f),
                strokeWidth = 6f
            )
            if (diagramType == "cold_joint") {
                // Good volcano on left
                val good = Path().apply {
                    moveTo(w * 0.25f, h * 0.68f)
                    quadraticTo(w * 0.30f, h * 0.56f, w * 0.31f, h * 0.42f)
                    lineTo(w * 0.35f, h * 0.42f)
                    quadraticTo(w * 0.36f, h * 0.56f, w * 0.41f, h * 0.68f)
                    close()
                }
                drawPath(good, color = SafeGreen)
                // Bad cold ball on right
                drawCircle(color = DangerRed, radius = 16f, center = Offset(w * 0.70f, h * 0.54f))
            } else if (diagramType == "track") {
                // Broken copper track + blue jumper wire
                drawLine(SafetyAmber, Offset(w * 0.15f, h * 0.76f), Offset(w * 0.42f, h * 0.76f), 6f)
                drawLine(SafetyAmber, Offset(w * 0.58f, h * 0.76f), Offset(w * 0.85f, h * 0.76f), 6f)
                val jumper = Path().apply {
                    moveTo(w * 0.36f, h * 0.76f)
                    quadraticTo(w * 0.50f, h * 0.25f, w * 0.64f, h * 0.76f)
                }
                drawPath(jumper, color = ElectricBlue, style = Stroke(4.5f))
            } else {
                // Good volcano fillet + 45 deg iron tip
                val fillet = Path().apply {
                    moveTo(w * 0.41f, h * 0.64f)
                    quadraticTo(w * 0.48f, h * 0.56f, w * 0.49f, h * 0.42f)
                    lineTo(w * 0.51f, h * 0.42f)
                    quadraticTo(w * 0.52f, h * 0.56f, w * 0.59f, h * 0.64f)
                    close()
                }
                drawPath(fillet, color = Color(0xFFCBD5E1))
                // 45 deg Soldering iron tip from right
                drawLine(
                    color = ElectricBlue,
                    start = Offset(w * 0.55f, h * 0.54f),
                    end = Offset(w * 0.80f, h * 0.20f),
                    strokeWidth = 10f,
                    cap = StrokeCap.Round
                )
            }
        }
        Text(text = caption, color = SafetyAmber, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun CircuitSchematicCard(diagramType: String, title: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF071122), RoundedCornerShape(12.dp))
            .border(1.dp, ElectricBlue.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "शैक्षिक सर्किट ब्लॉक डायग्राम", color = ElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .padding(top = 6.dp)
        ) {
            val w = size.width
            val h = size.height
            val cy = h / 2f
            val boxW = w * 0.24f
            val boxH = 42f
            val xs = listOf(w * 0.06f, w * 0.38f, w * 0.70f)
            val colors = listOf(SafetyAmber, ElectricBlue, SafeGreen)

            xs.forEachIndexed { idx, x ->
                drawRoundRect(
                    color = colors[idx].copy(alpha = 0.16f),
                    topLeft = Offset(x, cy - boxH / 2f),
                    size = Size(boxW, boxH),
                    cornerRadius = CornerRadius(10f, 10f)
                )
                drawRoundRect(
                    color = colors[idx],
                    topLeft = Offset(x, cy - boxH / 2f),
                    size = Size(boxW, boxH),
                    cornerRadius = CornerRadius(10f, 10f),
                    style = Stroke(2.5f)
                )
                if (idx < xs.lastIndex) {
                    val startX = x + boxW
                    val endX = xs[idx + 1]
                    drawLine(SkyCyan, Offset(startX, cy), Offset(endX, cy), 3.5f)
                    drawCircle(SkyCyan, radius = 4f, center = Offset(endX - 4f, cy))
                }
            }
        }
        val flowText = when (diagramType) {
            "rectifier_circuit" -> "AC Input → Bridge Diode (4×1N4007) → Pulsating DC"
            "filter_circuit" -> "Pulsating DC → Filter Capacitor (1000uF) → Smooth DC"
            "regulator_circuit" -> "12V DC IN → 7805 Regulator (GND) → Stable +5V OUT"
            "amplifier_circuit" -> "Audio IN → Coupling Cap → Amp IC → Speaker (4Ω–8Ω)"
            "flowchart" -> "Visual Check (Unplugged) → Safe Test → Isolate / Technician"
            else -> "Input Stage → Processing / Regulation → Output Stage"
        }
        Text(
            text = "$title: $flowText",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp
        )
    }
}
