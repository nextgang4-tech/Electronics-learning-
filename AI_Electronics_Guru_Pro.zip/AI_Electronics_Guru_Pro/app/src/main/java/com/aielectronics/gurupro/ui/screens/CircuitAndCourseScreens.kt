package com.aielectronics.gurupro.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.content.CircuitLearningData
import com.aielectronics.gurupro.data.content.CourseData
import com.aielectronics.gurupro.ui.components.CircuitSchematicCard
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.util.bi

@Composable
fun CircuitLearningScreen(lang: AppLanguage) {
    var selected by remember { mutableStateOf(CircuitLearningData.allLessons.first()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "📐 सर्किट डायग्राम और PCB लर्निंग", "📐 Circuit Diagram & PCB Learning"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CircuitLearningData.allLessons) { lesson ->
                    FilterChip(
                        selected = selected.id == lesson.id,
                        onClick = { selected = lesson },
                        label = { Text(lesson.titleHi, fontSize = 12.sp) }
                    )
                }
            }
        }

        item {
            CircuitSchematicCard(diagramType = selected.diagramType, title = selected.titleEn)
        }

        item { DetailSectionCard(selected.titleHi, selected.overview) }
        item { DetailBulletCard(bi(lang, "🔑 मुख्य बातें (Key Points)", "🔑 Key Points"), selected.keyPoints) }
        item { DetailBulletCard(bi(lang, "🧭 ट्रबलशूटिंग स्टेप्स", "🧭 Troubleshooting Steps"), selected.troubleshootingSteps) }
    }
}

@Composable
fun CourseScreen(
    prefs: AppPreferences,
    lang: AppLanguage
) {
    val context = LocalContext.current
    var completedLevels by remember { mutableStateOf(prefs.loadCompletedCourseLevels()) }
    var selectedLevel by remember { mutableStateOf(CourseData.allLevels.first()) }
    val selectedAnswers = remember(selectedLevel.level) { mutableStateMapOf<Int, Int>() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "🎓 10-लेवल कंप्लीट बिगिनर कोर्स", "🎓 Complete 10-Level Beginner Course"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { completedLevels.size / 10f },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = SafeGreen
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "${completedLevels.size} / 10 लेवल पूरे हो चुके हैं",
                fontSize = 12.sp,
                color = SafeGreen,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Level Selector
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CourseData.allLevels) { lvl ->
                    val done = completedLevels.contains(lvl.level)
                    FilterChip(
                        selected = selectedLevel.level == lvl.level,
                        onClick = { selectedLevel = lvl },
                        label = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (done) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SafeGreen)
                                    Spacer(Modifier.width(4.dp))
                                }
                                Text("Level ${lvl.level}", fontSize = 12.sp)
                            }
                        }
                    )
                }
            }
        }

        // Lesson Content
        item {
            DetailSectionCard(selectedLevel.titleHi, selectedLevel.lessonContent)
        }

        // Practice Questions
        item {
            DetailBulletCard(bi(lang, "✍️ अभ्यास प्रश्न (Practice Tasks)", "✍️ Practice Questions"), selectedLevel.practiceQuestions)
        }

        // Interactive Quiz
        item {
            Text(
                text = bi(lang, "🧠 लेवल ${selectedLevel.level} क्विज़ (Quiz)", "🧠 Level ${selectedLevel.level} Quiz"),
                fontWeight = FontWeight.Bold,
                color = ElectricBlue,
                fontSize = 16.sp
            )
        }

        items(selectedLevel.quiz.indices.toList()) { qIdx ->
            val q = selectedLevel.quiz[qIdx]
            val picked = selectedAnswers[qIdx]
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Q${qIdx + 1}. ${q.question}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    q.options.forEachIndexed { optIdx, optText ->
                        val isChosen = picked == optIdx
                        val isCorrect = optIdx == q.correctIndex
                        val borderCol = when {
                            picked == null -> MaterialTheme.colorScheme.outline
                            isChosen && isCorrect -> SafeGreen
                            isChosen && !isCorrect -> DangerRed
                            isCorrect -> SafeGreen
                            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(borderCol.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                                .border(1.dp, borderCol, RoundedCornerShape(10.dp))
                                .clickable { selectedAnswers[qIdx] = optIdx }
                                .padding(10.dp)
                        ) {
                            Text(optText, fontSize = 13.sp)
                        }
                    }
                    if (picked != null) {
                        val correct = picked == q.correctIndex
                        Text(
                            text = (if (correct) "✅ सही उत्तर! " else "❌ गलत उत्तर। ") + q.explanation,
                            color = if (correct) SafeGreen else DangerRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Mark Level Completed Button
        item {
            val isAlreadyDone = completedLevels.contains(selectedLevel.level)
            Button(
                onClick = {
                    prefs.markCourseLevelCompleted(selectedLevel.level)
                    completedLevels = prefs.loadCompletedCourseLevels()
                    Toast.makeText(context, "लेवल ${selectedLevel.level} पूरा हुआ! 🎉", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    if (isAlreadyDone) "✅ लेवल ${selectedLevel.level} पूर्ण हो चुका है"
                    else "लेवल ${selectedLevel.level} पूर्ण (Complete) चिह्नित करें",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
