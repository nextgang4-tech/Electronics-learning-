package com.aielectronics.gurupro.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.BookmarkItem
import com.aielectronics.gurupro.data.content.ComponentsData
import com.aielectronics.gurupro.ui.components.ComponentSymbolDiagram
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.util.bi

@Composable
fun ComponentsScreen(
    prefs: AppPreferences,
    lang: AppLanguage
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var bookmarkedIds by remember {
        mutableStateOf(prefs.loadBookmarks().map { it.id }.toSet())
    }

    val filtered = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) ComponentsData.allComponents
        else ComponentsData.allComponents.filter { item ->
            item.nameHi.lowercase().contains(q) ||
                item.nameEn.lowercase().contains(q) ||
                item.pcbMarkings.any { it.lowercase().contains(q) } ||
                item.purpose.lowercase().contains(q)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "🔬 इलेक्ट्रॉनिक कंपोनेंट आइडेंटिफ़ायर", "🔬 Electronic Component Identifier"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = {
                    Text(
                        bi(lang, "नाम या PCB मार्किंग खोजें: R1, 1N4007, 7805, Q1, 104...", "Search name or marking: R1, 1N4007, 7805, Q1..."),
                        fontSize = 13.sp
                    )
                }
            )
        }

        items(filtered, key = { it.id }) { comp ->
            val bmId = "comp_${comp.id}"
            val isBm = bookmarkedIds.contains(bmId)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(comp.nameHi, fontWeight = FontWeight.Bold, color = ElectricBlue, fontSize = 16.sp)
                            Text(
                                "PCB मार्किंग: ${comp.pcbMarkings.joinToString(", ")}",
                                fontSize = 12.sp,
                                color = SafeGreen,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        IconButton(onClick = {
                            val list = prefs.loadBookmarks().toMutableList()
                            if (isBm) list.removeAll { it.id == bmId }
                            else list.add(0, BookmarkItem(bmId, "कंपोनेंट", comp.nameHi, "components"))
                            prefs.saveBookmarks(list)
                            bookmarkedIds = list.map { it.id }.toSet()
                            Toast.makeText(context, if (!isBm) "बुकमार्क सेव हुआ" else "बुकमार्क हटाया गया", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(
                                if (isBm) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = "Bookmark",
                                tint = ElectricBlue
                            )
                        }
                    }

                    ComponentSymbolDiagram(diagramType = comp.diagramType, label = comp.symbolDescription)

                    Text("• उपयोग (Purpose): ${comp.purpose}", fontSize = 13.sp)
                    Text("• पिनआउट (Pinout): ${comp.pinout}", fontSize = 13.sp)
                    Text("• टेस्टिंग विधि (Testing): ${comp.testingMethod}", fontSize = 13.sp)
                    Text("⚠️ सुरक्षा: ${comp.safetyNote}", fontSize = 12.sp, color = SafetyAmber)
                }
            }
        }
    }
}
