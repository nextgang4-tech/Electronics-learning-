package com.aielectronics.gurupro.data.content

import com.aielectronics.gurupro.data.ComponentItem

object ComponentsData {
    val allComponents: List<ComponentItem> = listOf(
        ComponentItem(
            id = "resistor",
            nameHi = "रेजिस्टर (Resistor)",
            nameEn = "Resistor",
            pcbMarkings = listOf("R", "R1", "R10", "103", "472", "100", "220R"),
            diagramType = "resistor",
            purpose = "सर्किट में करंट के बहाव को सीमित (Limit) करना और वोल्टेज डिवाइड करना (जैसे LED को जलने से बचाना)।",
            symbolDescription = "ज़िग-ज़ैग लाइन (US) या आयताकार बॉक्स (IEC) — दोनों तरफ दो लीड्स।",
            pinout = "नॉन-पोलर (Non-Polar) — कोई + या - नहीं होता, किसी भी दिशा में लगाया जा सकता है।",
            testingMethod = "पावर बंद करके मल्टीमीटर को ओम (Ω) रेंज पर रखें। रीडिंग कलर कोड या SMD कोड (जैसे 103 = 10kΩ) के आसपास आनी चाहिए।",
            safetyNote = "चालू सर्किट पर कभी Ω मोड से टेस्ट न करें।"
        ),
        ComponentItem(
            id = "capacitor_general",
            nameHi = "कैपेसिटर (Capacitor - सामान्य)",
            nameEn = "Capacitor",
            pcbMarkings = listOf("C", "C1", "C10", "104", "474", "X2"),
            diagramType = "capacitor",
            purpose = "विद्युत ऊर्जा को अस्थायी रूप से स्टोर करना, DC वोल्टेज को स्मूथ/फ़िल्टर करना और AC सिग्नल पास करके DC को ब्लॉक करना।",
            symbolDescription = "दो समानांतर सीधी रेखाएं (नॉन-पोलर) या एक सीधी व एक मुड़ी हुई रेखा (पोलराइज़्ड)।",
            pinout = "नॉन-पोलर (फिल्म/सिरेमिक) में कोई + / - नहीं; पोलराइज़्ड में + और - होता है।",
            testingMethod = "पहले सुरक्षित डिस्चार्ज करें, फिर कैपेसिटेंस (uF/nF) मोड में वैल्यू चेक करें और कंटिन्यूटी में शॉर्ट न होने की पुष्टि करें।",
            safetyNote = "बड़े हाई-वोल्टेज कैपेसिटर अनप्लग करने के बाद भी करंट रख सकते हैं!"
        ),
        ComponentItem(
            id = "ceramic_capacitor",
            nameHi = "सिरेमिक कैपेसिटर (Ceramic Capacitor)",
            nameEn = "Ceramic Capacitor",
            pcbMarkings = listOf("C", "104", "103", "22pF", "102", "PF"),
            diagramType = "ceramic_cap",
            purpose = "हाई-फ़्रीक्वेंसी नॉइज़ को फ़िल्टर (Decoupling) करना, क्रिस्टल ऑसिलेटर के साथ काम करना।",
            symbolDescription = "दो बराबर समानांतर रेखाएं (बिना + चिह्न के)।",
            pinout = "नॉन-पोलर — किसी भी दिशा में लगाया जा सकता है। कोड 104 = 10 × 10⁴ pF = 100nF (0.1uF)।",
            testingMethod = "अनप्लग अवस्था में कंटिन्यूटी मोड में बीप नहीं आनी चाहिए (बीप = शॉर्ट)। कैपेसिटेंस मोड में nF/pF चेक करें।",
            safetyNote = "नीले रंग के Y-सेफ्टी सिरेमिक कैपेसिटर SMPS आइसोलेशन के लिए होते हैं — इन्हें साधारण कैपेसिटर से न बदलें।"
        ),
        ComponentItem(
            id = "electrolytic_capacitor",
            nameHi = "इलेक्ट्रोलाइटिक कैपेसिटर (Electrolytic Capacitor)",
            nameEn = "Electrolytic Capacitor",
            pcbMarkings = listOf("EC", "C", "470uF", "1000uF", "2200uF", "400V"),
            diagramType = "electrolytic_cap",
            purpose = "पावर सप्लाई में रिपल हटाकर स्थिर DC वोल्टेज देना और बड़ी मात्रा में चार्ज स्टोर करना।",
            symbolDescription = "एक सीधी रेखा (+) और एक घुमावदार या खाली बॉक्स रेखा (-)।",
            pinout = "पोलराइज़्ड: लंबा पैर पॉजिटिव (+) और सफेद/काली पट्टी वाला छोटा पैर नेगेटिव (-) होता है।",
            testingMethod = "पहले देखें कि ऊपर का हिस्सा फूला (Bulged) या लीक तो नहीं। डिस्चार्ज करके uF वैल्यू और शॉर्टिंग चेक करें।",
            safetyNote = "उल्टा लगाने या ओवर-वोल्टेज देने पर यह फट सकता है! 400V कैपेसिटर खतरनाक चार्ज रखता है।"
        ),
        ComponentItem(
            id = "diode",
            nameHi = "डायोड (Diode)",
            nameEn = "Diode",
            pcbMarkings = listOf("D", "D1", "1N4007", "1N5408", "1N4148", "SS34", "M7"),
            diagramType = "diode",
            purpose = "करंट को केवल एक ही दिशा में बहने देना — AC को DC में बदलने (Rectification) और रिवर्स पोलैरिटी सुरक्षा के लिए।",
            symbolDescription = "एक त्रिभुज (एनोड +) जो एक सीधी खड़ी रेखा (कैथोड -) की ओर इशारा करता है।",
            pinout = "2 पिन: बिना पट्टी वाला एनोड (+) और सिल्वर/सफेद पट्टी वाला कैथोड (-)।",
            testingMethod = "अनप्लग अवस्था में डायोड मोड पर: एनोड (+) पर लाल व कैथोड (-) पर काला प्रोब रखने पर 500–700 रीडिंग; पलटने पर OL।",
            safetyNote = "सर्किट में लगे होने पर अन्य कंपोनेंट के कारण रीडिंग बदल सकती है — पुष्टि के लिए एक लेग अलग करें।"
        ),
        ComponentItem(
            id = "zener_diode",
            nameHi = "ज़ेनर डायोड (Zener Diode)",
            nameEn = "Zener Diode",
            pcbMarkings = listOf("ZD", "Z", "5V1", "12V", "1N4733", "1N4742"),
            diagramType = "zener",
            purpose = "रिवर्स बायस में एक निश्चित वोल्टेज (जैसे 5.1V या 12V) को स्थिर (Regulate) बनाए रखना और ओवर-वोल्टेज सुरक्षा देना।",
            symbolDescription = "डायोड जैसा ही, लेकिन कैथोड की खड़ी रेखा के सिरे 'Z' आकार में मुड़े होते हैं।",
            pinout = "2 पिन: काली पट्टी वाला सिरा कैथोड (-) होता है। इसे सर्किट में रिवर्स बायस में लगाया जाता है।",
            testingMethod = "डायोड मोड में सामान्य डायोड की तरह एक तरफ 500–750 और दूसरी तरफ OL दिखाता है (दोनों तरफ 000 = शॉर्ट)।",
            safetyNote = "ज़ेनर डायोड के साथ हमेशा सीरीज करंट-लिमिटिंग रेजिस्टर होना चाहिए।"
        ),
        ComponentItem(
            id = "led",
            nameHi = "LED (Light Emitting Diode)",
            nameEn = "LED",
            pcbMarkings = listOf("LED", "D", "SMD 2835", "5mm LED"),
            diagramType = "led",
            purpose = "बिजली से रोशनी उत्पन्न करना (इंडिकेटर, डिस्प्ले बैकलाइट, LED बल्ब)।",
            symbolDescription = "डायोड सिंबल जिसके ऊपर से बाहर की ओर दो छोटे तीर निकलते हैं।",
            pinout = "लंबा पैर एनोड (+) और छोटा पैर (चपटे किनारे की तरफ) कैथोड (-) होता है।",
            testingMethod = "डायोड मोड में लाल प्रोब एनोड (+) और काला कैथोड (-) पर लगाने से अधिकांश 3V LED हल्की जल उठती हैं।",
            safetyNote = "साधारण 5mm LED को सीधे 5V या 12V से न जोड़ें — हमेशा सीरीज रेजिस्टर (220Ω–1kΩ) लगाएं।"
        ),
        ComponentItem(
            id = "transistor",
            nameHi = "ट्रांजिस्टर (BJT Transistor - NPN/PNP)",
            nameEn = "Transistor",
            pcbMarkings = listOf("Q", "TR", "BC547", "BC557", "2N2222", "S8050", "TIP122", "1AM"),
            diagramType = "transistor",
            purpose = "इलेक्ट्रॉनिक स्विच की तरह काम करना और कमजोर सिग्नल को बढ़ाना (Amplification)।",
            symbolDescription = "बेस (B) लाइन से कलेक्टर (C) और एमिटर (E) निकलते हैं — NPN में तीर बाहर की ओर, PNP में अंदर की ओर।",
            pinout = "3 पिन: Base (B), Collector (C), Emitter (E) — पिन क्रम हर मॉडल (जैसे BC547 = C-B-E) की डेटाशीट से जांचें।",
            testingMethod = "डायोड मोड में बेस से C और E दोनों पर ~600–750 रीडिंग आनी चाहिए, और C-E के बीच दोनों तरफ OL।",
            safetyNote = "अलग-अलग ट्रांजिस्टर का पिनआउट अलग हो सकता है — बदलने से पहले नंबर ज़रूर मिलाएं।"
        ),
        ComponentItem(
            id = "mosfet",
            nameHi = "MOSFET (मॉसफेट)",
            nameEn = "MOSFET",
            pcbMarkings = listOf("Q", "M", "IRFZ44N", "IRF540", "7N65", "10N60", "AO3400"),
            diagramType = "mosfet",
            purpose = "हाई-स्पीड और हाई-करंट स्विचिंग (SMPS, इन्वर्टर, मोटर कंट्रोल, बक कन्वर्टर)।",
            symbolDescription = "इंसुलेटेड गेट (G) लाइन, और दूसरी तरफ ड्रेन (D) व सोर्स (S) के साथ अंदरूनी बॉडी डायोड।",
            pinout = "TO-220 पैकेज (सीधा देखने पर बाएं से दाएं): आमतौर पर Pin 1 = Gate (G), Pin 2 = Drain (D), Pin 3 = Source (S)।",
            testingMethod = "अनप्लग व बोर्ड से निकालकर डायोड मोड में: Drain-Source में एक तरफ बॉडी डायोड (400–600) और दूसरी तरफ OL; Gate किसी से शॉर्ट नहीं होना चाहिए।",
            safetyNote = "MOSFET स्टैटिक बिजली (ESD) से संवेदनशील होते हैं और SMPS में हाई वोल्टेज पर काम करते हैं।"
        ),
        ComponentItem(
            id = "ic",
            nameHi = "IC (इंटीग्रेटेड सर्किट / चिप)",
            nameEn = "Integrated Circuit (IC)",
            pcbMarkings = listOf("U", "IC", "NE555", "LM358", "4558", "PAM8403", "ATmega328P"),
            diagramType = "ic",
            purpose = "एक छोटे पैकेज के अंदर सैकड़ों से लाखों ट्रांजिस्टर मिलाकर विशेष काम करना (टाइमर, ऑडियो, लॉजिक, माइक्रोकंट्रोलर)।",
            symbolDescription = "पिन नंबरों के साथ आयताकार ब्लॉक या ऑप-एम्प के लिए त्रिभुज।",
            pinout = "IC पर बने गोल डॉट या U-आकार के नॉच (Notch) के बाईं ओर Pin 1 होता है; गिनती घड़ी के विपरीत (Counter-clockwise) चलती है।",
            testingMethod = "अनप्लग अवस्था में VCC और GND पिन के बीच शॉर्ट सर्किट चेक करें, और विज़ुअल रूप से कोई छेद या जलन देखें।",
            safetyNote = "IC उल्टी लगाने से पावर देते ही तुरंत जल जाएगी — Pin 1 डॉट हमेशा मिलाएं।"
        ),
        ComponentItem(
            id = "relay",
            nameHi = "रिले (Relay)",
            nameEn = "Relay",
            pcbMarkings = listOf("K", "RL", "RY", "5V", "12V", "SRD-12VDC"),
            diagramType = "relay",
            purpose = "छोटे DC सिग्नल (5V/12V) से बड़े AC या हाई-करंट लोड को सुरक्षित आइसोलेशन के साथ ऑन/ऑफ करना।",
            symbolDescription = "एक इलेक्ट्रोमैग्नेटिक कॉइल बॉक्स और उसके पास स्विच कॉन्टैक्ट (COM, NO, NC)।",
            pinout = "5 पिन रिले: 2 कॉइल पिन, 1 कॉमन (COM), 1 नॉर्मली क्लोज़्ड (NC), 1 नॉर्मली ओपन (NO)।",
            testingMethod = "अनप्लग अवस्था में कॉइल पिनों पर 70Ω–400Ω रेजिस्टेंस आना चाहिए। COM और NC के बीच बीप, COM और NO के बीच OL (कॉइल बंद होने पर)।",
            safetyNote = "रिले के कॉन्टैक्ट पर 230V AC हो सकता है — लाइव अवस्था में रिले पिन न छुएं।"
        ),
        ComponentItem(
            id = "fuse",
            nameHi = "फ्यूज़ (Fuse)",
            nameEn = "Fuse",
            pcbMarkings = listOf("F", "F1", "FU", "T2A", "5A 250V"),
            diagramType = "fuse",
            purpose = "ओवर-करंट या शॉर्ट सर्किट होने पर खुद पिघलकर पूरे सर्किट और घर को आग लगने से बचाना।",
            symbolDescription = "दो बिंदुओं के बीच S-आकार की लहर या आयताकार बॉक्स से गुज़रती सीधी लाइन।",
            pinout = "2 टर्मिनल (नॉन-पोलर) — हमेशा सप्लाई के सीरीज में लगा होता है।",
            testingMethod = "होल्डर से निकालकर कंटिन्यूटी (बीप) मोड में चेक करें — बीप = ठीक, OL = उड़ा हुआ।",
            safetyNote = "कभी भी फ्यूज़ को बाईपास न करें या ज़्यादा एम्पियर का फ्यूज़ न लगाएं!"
        ),
        ComponentItem(
            id = "transformer",
            nameHi = "ट्रांसफॉर्मर (Transformer)",
            nameEn = "Transformer",
            pcbMarkings = listOf("T", "TR", "TX", "12-0-12", "EE16"),
            diagramType = "transformer",
            purpose = "AC वोल्टेज को कम (Step-Down) या ज़्यादा (Step-Up) करना और प्राइमरी व सेकेंडरी के बीच इलेक्ट्रिकल आइसोलेशन देना।",
            symbolDescription = "दो कॉइल (प्राइमरी और सेकेंडरी) जिनके बीच कोर की दो सीधी रेखाएं होती हैं।",
            pinout = "प्राइमरी वाइंडिंग (आमतौर पर 2 तार) और सेकेंडरी वाइंडिंग (2 या 3 तार जैसे 12-0-12)।",
            testingMethod = "अनप्लग अवस्था में प्राइमरी और सेकेंडरी वाइंडिंग पर अलग-अलग ओम रीडिंग आनी चाहिए, और प्राइमरी से सेकेंडरी के बीच OL (कोई शॉर्ट नहीं)।",
            safetyNote = "230V ट्रांसफॉर्मर के प्राइमरी सिरों पर इंसुलेशन हमेशा पक्का रखें।"
        ),
        ComponentItem(
            id = "inductor",
            nameHi = "कॉइल और इंडक्टर (Coil / Inductor)",
            nameEn = "Coils & Inductors",
            pcbMarkings = listOf("L", "L1", "CH", "100uH", "220", "4R7"),
            diagramType = "inductor",
            purpose = "चुंबकीय क्षेत्र में ऊर्जा स्टोर करना, हाई-फ़्रीक्वेंसी नॉइज़ रोकना और बक/बूस्ट कन्वर्टर में वोल्टेज बदलना।",
            symbolDescription = "लगातार घुमावदार लूप्स (कॉइल स्प्रिंग जैसा चिह्न)।",
            pinout = "नॉन-पोलर 2 पिन (ट्रांसफॉर्मर कॉमन-मोड चोक में 4 पिन हो सकते हैं)।",
            testingMethod = "अनप्लग अवस्था में कंटिन्यूटी (बीप) या बहुत कम रेजिस्टेंस (0.1Ω–10Ω) दिखाता है। OL आए तो कॉइल अंदर से टूटी है।",
            safetyNote = "बड़े इंडक्टर में करंट बंद होते समय वोल्टेज स्पाइक बनता है — इसलिए फ्लाईबैक डायोड इस्तेमाल होता है।"
        ),
        ComponentItem(
            id = "connector",
            nameHi = "कनेक्टर और पोर्ट (Connectors)",
            nameEn = "Connectors",
            pcbMarkings = listOf("J", "CN", "CON", "P1", "USB", "DC_IN"),
            diagramType = "connector",
            purpose = "अलग-अलग PCB, केबल, बैटरी, स्पीकर या चार्जर को सुरक्षित और आसानी से जोड़ना/हटाना।",
            symbolDescription = "पिन हेडर बॉक्स या प्लग/जैक सिंबल।",
            pinout = "JST (बैटरी/स्पीकर), USB-C/Micro-USB, DC बैरल जैक, RCA और FFC रिबन कनेक्टर।",
            testingMethod = "पहले जंग, मुड़ी हुई पिन और उखड़े सोल्डर पैड देखें; फिर अनप्लग अवस्था में केबल से PCB पैड तक कंटिन्यूटी चेक करें।",
            safetyNote = "रिबन (FFC) कनेक्टर का लॉक हमेशा हल्के से उठाकर केबल निकालें, खींचें नहीं।"
        ),
        ComponentItem(
            id = "switch",
            nameHi = "स्विच और पुश बटन (Switches)",
            nameEn = "Switches",
            pcbMarkings = listOf("SW", "S1", "K1", "PWR", "RST"),
            diagramType = "switch",
            purpose = "सर्किट को मैन्युअल रूप से जोड़ना (ON) या तोड़ना (OFF)।",
            symbolDescription = "दो टर्मिनल के बीच एक खुली या बंद लिवर लाइन।",
            pinout = "टैक्टाइल बटन (2 या 4 पिन), स्लाइड स्विच (SPDT 3 पिन), रॉकर स्विच।",
            testingMethod = "अनप्लग अवस्था में कंटिन्यूटी मोड में बटन दबाने पर बीप आनी चाहिए और छोड़ने पर OL (NO स्विच के लिए)।",
            safetyNote = "230V मेन स्विच की टेस्टिंग हमेशा प्लग निकालकर करें।"
        ),
        ComponentItem(
            id = "regulator",
            nameHi = "वोल्टेज रेगुलेटर (Voltage Regulator)",
            nameEn = "Voltage Regulators",
            pcbMarkings = listOf("VR", "REG", "U", "7805", "7812", "AMS1117-3.3", "LM317"),
            diagramType = "regulator",
            purpose = "बदलते हुए इनपुट वोल्टेज से एक बिल्कुल स्थिर DC आउटपुट वोल्टेज (जैसे 5V या 3.3V) प्रदान करना।",
            symbolDescription = "3-टर्मिनल बॉक्स: IN, GND, OUT।",
            pinout = "7805 (सीधा देखने पर): Pin 1 = Input (7V–24V), Pin 2 = GND, Pin 3 = Output (5V) | AMS1117: Pin 1 = GND, Pin 2 = OUT, Pin 3 = IN।",
            testingMethod = "अनप्लग में GND से IN/OUT शॉर्ट न हो। लो-वोल्टेज पावर देने पर आउटपुट पिन पर सटीक 5.0V (7805) या 3.3V (AMS1117) मिलना चाहिए।",
            safetyNote = "लीनियर रेगुलेटर (7805) ज़्यादा करंट पर बहुत गर्म होता है — हीटसिंक का उपयोग करें।"
        ),
        ComponentItem(
            id = "sensor",
            nameHi = "सेंसर (Sensors)",
            nameEn = "Sensors",
            pcbMarkings = listOf("NTC", "LDR", "IR", "HALL", "DHT11", "PIR"),
            diagramType = "sensor",
            purpose = "वातावरण के बदलाव (रोशनी, तापमान, गति, चुंबक, IR सिग्नल) को इलेक्ट्रिकल सिग्नल में बदलना।",
            symbolDescription = "कंपोनेंट सिंबल जिस पर अंदर की ओर आते तीर (प्रकाश/तापमान) बने होते हैं।",
            pinout = "LDR और NTC: 2 पिन (नॉन-पोलर) | IR रिसीवर (TSOP1838): OUT, GND, VCC।",
            testingMethod = "LDR पर रोशनी डालने से उसका रेजिस्टेंस (Ω) घटता है और अंधेरे में बढ़ता है। NTC गर्म होने पर रेजिस्टेंस घटता है।",
            safetyNote = "सेंसर मॉड्यूल को हमेशा तय 3.3V या 5V सप्लाई ही दें।"
        )
    )
}
