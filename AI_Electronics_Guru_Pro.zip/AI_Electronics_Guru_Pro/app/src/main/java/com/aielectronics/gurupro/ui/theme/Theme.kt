package com.aielectronics.gurupro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.ThemeMode

val DeepBlackNavy = Color(0xFF030712)
val DarkNavySurface = Color(0xFF0A1428)
val DarkNavyCard = Color(0xFF111F38)
val DarkNavyBorder = Color(0xFF1E3A5F)
val ElectricBlue = Color(0xFF00D4FF)
val RoyalBlue = Color(0xFF2563EB)
val SkyCyan = Color(0xFF38BDF8)
val SafetyAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)
val SafeGreen = Color(0xFF10B981)

val LightBg = Color(0xFFF0F6FF)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFE6F0FF)
val LightPrimary = Color(0xFF0284C7)
val LightSecondary = Color(0xFF1D4ED8)
val LightText = Color(0xFF0B1F3A)
val LightSubText = Color(0xFF475569)

private val DarkColors = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = DeepBlackNavy,
    primaryContainer = Color(0xFF0D2B4E),
    onPrimaryContainer = Color(0xFFB8F3FF),
    secondary = SkyCyan,
    onSecondary = DeepBlackNavy,
    secondaryContainer = Color(0xFF15294A),
    onSecondaryContainer = Color(0xFFD6EEFF),
    tertiary = SafetyAmber,
    onTertiary = DeepBlackNavy,
    background = DeepBlackNavy,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkNavySurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = DarkNavyCard,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = DarkNavyBorder,
    error = DangerRed,
    onError = Color.White,
    errorContainer = Color(0xFF450A0A),
    onErrorContainer = Color(0xFFFECACA)
)

private val LightColors = lightColorScheme(
    primary = LightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF0C4A6E),
    secondary = LightSecondary,
    onSecondary = Color.White,
    secondaryContainer = LightCard,
    onSecondaryContainer = LightText,
    tertiary = Color(0xFFD97706),
    onTertiary = Color.White,
    background = LightBg,
    onBackground = LightText,
    surface = LightSurface,
    onSurface = LightText,
    surfaceVariant = LightCard,
    onSurfaceVariant = LightSubText,
    outline = Color(0xFFBFDBFE),
    error = Color(0xFFDC2626),
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF7F1D1D)
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 19.sp,
        lineHeight = 25.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun AIElectronicsGuruTheme(
    themeMode: ThemeMode,
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (useDark) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
