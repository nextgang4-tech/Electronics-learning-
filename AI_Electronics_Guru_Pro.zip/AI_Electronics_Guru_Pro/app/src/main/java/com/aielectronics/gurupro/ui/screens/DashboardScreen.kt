package com.aielectronics.gurupro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Troubleshoot
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.SearchResultItem
import com.aielectronics.gurupro.data.content.CategoriesData
import com.aielectronics.gurupro.data.content.CircuitLearningData
import com.aielectronics.gurupro.data.content.ComponentsData
import com.aielectronics.gurupro.data.content.CourseData
import com.aielectronics.gurupro.data.content.ExtrasData
import com.aielectronics.gurupro.data.content.MultimeterData
import com.aielectronics.gurupro.data.content.SolderingData
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.RoyalBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.util.bi

private data class FeatureCardItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val route: String
)

@Composable
fun DashboardScreen(
    prefs: AppPreferences,
    lang: AppLanguage,
    onNavigate: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var searchHistory by remember { mutableStateOf(prefs.loadSearchHistory()) }
    val completedLevels = remember { prefs.loadCompletedCourseLevels() }
    val savedCasesCount = remember { prefs.loadSavedCases().size }
    val bookmarksCount = remember { prefs.loadBookmarks().size }

    val searchResults = remember(searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.length < 2) emptyList()
        else buildList {
            CategoriesData.allCategories.filter {
                it.titleHi.lowercase().contains(q) || it.titleEn.lowercase().contains(q) ||
                    it.workingPrinciple.lowercase().contains(q)
            }.forEach {
                add(SearchResultItem(it.titleHi, it.titleEn, "रिपेयर कैटेगरी", "category_detail/${it.id}"))
            }
            ComponentsData.allComponents.filter {
                it.nameHi.lowercase().contains(q) || it.nameEn.lowercase().contains(q) ||
                    it.pcbMarkings.any { m -> m.lowercase().contains(q) }
            }.forEach {
                add(SearchResultItem(it.nameHi, "Markings: ${it.pcbMarkings.take(4).joinToString()}", "कंपोनेंट", "components"))
            }
            MultimeterData.allLessons.filter {
                it.titleHi.lowercase().contains(q) || it.titleEn.lowercase().contains(q)
            }.forEach {
                add(SearchResultItem(it.titleHi, it.dialSetting, "मल्टीमीटर", "multimeter"))
            }
            SolderingData.allLessons.filter {
                it.titleHi.lowercase().contains(q) || it.titleEn.lowercase().contains(q)
            }.forEach {
                add(SearchResultItem(it.titleHi, it.titleEn, "सोल्डरिंग", "soldering"))
            }
            CircuitLearningData.allLessons.filter {
                it.titleHi.lowercase().contains(q) || it.titleEn.lowercase().contains(q)
            }.forEach {
                add(SearchResultItem(it.titleHi, it.titleEn, "सर्किट", "circuits"))
            }
            CourseData.allLevels.filter {
                it.titleHi.lowercase().contains(q) || it.titleEn.lowercase().contains(q)
            }.forEach {
                add(SearchResultItem(it.titleHi, it.titleEn, "कोर्स", "course"))
            }
            ExtrasData.dictionaryTerms.filter {
                it.term.lowercase().contains(q) || it.hindiMeaning.lowercase().contains(q)
            }.forEach {
                add(SearchResultItem(it.term, it.hindiMeaning, "डिक्शनरी", "tools"))
            }
        }
    }

    val features = listOf(
        FeatureCardItem(
            bi(lang, "AI फोटो स्कैनर", "AI Photo Scanner"),
            bi(lang, "PCB फोटो से पार्ट्स व फॉल्ट समझें", "Camera ya Gallery se PCB scan"),
            Icons.Default.CameraAlt, ElectricBlue, "scanner"
        ),
        FeatureCardItem(
            bi(lang, "AI रिपेयर चैट", "AI Repair Chat"),
            bi(lang, "हिंदी में स्टेप-बाय-स्टेप मदद", "Hindi me repair sawal puchein"),
            Icons.Default.Chat, Color(0xFF38BDF8), "chat"
        ),
        FeatureCardItem(
            bi(lang, "AI फॉल्ट फाइंडर", "AI Fault Finder"),
            bi(lang, "7-स्टेप इंटरैक्टिव जांच", "Interactive fault diagnosis"),
            Icons.Default.Troubleshoot, Color(0xFF818CF8), "fault_finder"
        ),
        FeatureCardItem(
            bi(lang, "19 रिपेयर कैटेगरी", "19 Repair Categories"),
            bi(lang, "चार्जर, LED, फैन, TV, SMPS...", "All devices learning & theory"),
            Icons.Default.Build, SafeGreen, "categories"
        ),
        FeatureCardItem(
            bi(lang, "मल्टीमीटर ट्रेनर", "Multimeter Master"),
            bi(lang, "डायल, प्रोब और रीडिंग गाइड", "10 interactive tests + diagrams"),
            Icons.Default.Speed, SafetyAmber, "multimeter"
        ),
        FeatureCardItem(
            bi(lang, "सोल्डरिंग ट्रेनर", "Soldering Master"),
            bi(lang, "सोल्डरिंग, पंप, विक व ट्रैक", "10 illustrated soldering lessons"),
            Icons.Default.ElectricBolt, Color(0xFFFB7185), "soldering"
        ),
        FeatureCardItem(
            bi(lang, "कंपोनेंट पहचान", "Component Identifier"),
            bi(lang, "नाम या PCB मार्किंग से खोजें", "18 components + pinout + test"),
            Icons.Default.Memory, Color(0xFF2DD4BF), "components"
        ),
        FeatureCardItem(
            bi(lang, "सर्किट व PCB लर्निंग", "Circuit & PCB"),
            bi(lang, "डायग्राम, रेक्टिफायर व फ्लोचार्ट", "Schematics & track reading"),
            Icons.Default.DeveloperBoard, Color(0xFFA78BFA), "circuits"
        ),
        FeatureCardItem(
            bi(lang, "10-लेवल बिगिनर कोर्स", "Beginner Course"),
            bi(lang, "क्विज़ और प्रोग्रेस ट्रैकिंग", "Level 1 to 10 Hindi Course"),
            Icons.Default.School, Color(0xFF34D399), "course"
        ),
        FeatureCardItem(
            bi(lang, "टूल्स, कैलकुलेटर व सेफ्टी", "Tools & Calculators"),
            bi(lang, "ओम नियम, कलर कोड, नोट्स, सेफ्टी", "Calculators, Dictionary, Cases"),
            Icons.Default.Calculate, Color(0xFF60A5FA), "tools"
        )
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF0A1F44), Color(0xFF061024))),
                        RoundedCornerShape(18.dp)
                    )
                    .border(1.dp, ElectricBlue.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "⚡ AI Electronics Guru Pro",
                        color = ElectricBlue,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = bi(
                            lang,
                            "शून्य से इलेक्ट्रॉनिक्स और सुरक्षित रिपेयरिंग सीखें — हिंदी में AI गाइड के साथ।",
                            "Zero se electronics aur safe repairing seekhein — simple Hinglish AI guide ke saath."
                        ),
                        color = Color(0xFFE2E8F0),
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Global Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                placeholder = {
                    Text(
                        bi(
                            lang,
                            "खोजें: 1N4007, 7805, मल्टीमीटर, LED, SMPS...",
                            "Search: 1N4007, 7805, multimeter, LED, SMPS..."
                        ),
                        fontSize = 13.sp
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                }
            )
            if (searchQuery.isBlank() && searchHistory.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(searchHistory.take(6)) { h ->
                        SuggestionChip(
                            onClick = { searchQuery = h },
                            label = { Text(h, fontSize = 12.sp) }
                        )
                    }
                }
            }
        }

        // Search Results if typing
        if (searchQuery.trim().length >= 2) {
            if (searchResults.isEmpty()) {
                item {
                    Text(
                        text = bi(lang, "कोई परिणाम नहीं मिला।", "Koi result nahi mila."),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            } else {
                items(searchResults.take(15)) { res ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                prefs.addSearchHistory(searchQuery)
                                searchHistory = prefs.loadSearchHistory()
                                onNavigate(res.route)
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(res.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(res.subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                text = res.badge,
                                color = ElectricBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        } else {
            // Mandatory Safety Quick Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate("tools") },
                    colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.14f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DangerRed.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = SafetyAmber)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = bi(
                                lang,
                                "सुरक्षा पहले: 230V मेन, माइक्रोवेव, CRT TV, इन्वर्टर और चार्ज्ड कैपेसिटर पर लाइव काम कभी न करें। (सुरक्षा गाइड पढ़ें)",
                                "Safety First: 230V mains, microwave, CRT TV, inverter aur charged capacitors par live kaam kabhi na karein."
                            ),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Progress Dashboard Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate("course") },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = bi(lang, "आपकी सीखने की प्रगति", "Aapki Learning Progress"),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${completedLevels.size}/10 ${bi(lang, "लेवल", "Levels")}",
                                color = ElectricBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { completedLevels.size / 10f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            color = ElectricBlue,
                            trackColor = RoyalBlue.copy(alpha = 0.25f)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = bi(
                                lang,
                                "सेव किए गए केस: $savedCasesCount  •  बुकमार्क: $bookmarksCount",
                                "Saved Cases: $savedCasesCount  •  Bookmarks: $bookmarksCount"
                            ),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Feature Cards 2-Column Rows
            items(features.chunked(2)) { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pair.forEach { card ->
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(118.dp)
                                .clickable { onNavigate(card.route) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(15.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .border(
                                        1.dp,
                                        card.accent.copy(alpha = 0.35f),
                                        RoundedCornerShape(15.dp)
                                    )
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Icon(
                                    imageVector = card.icon,
                                    contentDescription = null,
                                    tint = card.accent,
                                    modifier = Modifier.size(28.dp)
                                )
                                Column {
                                    Text(
                                        text = card.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = card.subtitle,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }
                    if (pair.size == 1) {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
