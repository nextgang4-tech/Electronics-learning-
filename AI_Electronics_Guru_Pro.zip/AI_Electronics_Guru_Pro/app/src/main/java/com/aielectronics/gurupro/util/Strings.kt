package com.aielectronics.gurupro.util

import com.aielectronics.gurupro.data.AppLanguage

fun bi(lang: AppLanguage, hi: String, hinglish: String): String {
    return if (lang == AppLanguage.HINDI) hi else hinglish
}
