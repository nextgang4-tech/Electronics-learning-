package com.aielectronics.gurupro.data.content

import com.aielectronics.gurupro.data.MultimeterLesson

object MultimeterData {
    val mandatorySafetyBanner: String =
        "अनिवार्य सुरक्षा नियम: कभी भी चालू (Energized) सर्किट पर Resistance (Ω), Continuity (Beep) या Diode टेस्ट न करें! और कभी भी मल्टीमीटर को Current (A/mA) मोड में सीधे पावर सोर्स या बैटरी के पार (Parallel) न जोड़ें — इससे फ्यूज़ उड़ सकता है या स्पार्क हो सकता है।"

    val allLessons: List<MultimeterLesson> = listOf(
        MultimeterLesson(
            id = "dc_voltage",
            titleHi = "DC वोल्टेज मापना (DCV)",
            titleEn = "DC Voltage Measurement",
            diagramType = "dcv",
            isHighVoltageWarning = false,
            safetyRule = "अनुमानित वोल्टेज से हमेशा अगली बड़ी DCV रेंज चुनें (जैसे 5V चार्जर या 12V बैटरी के लिए 20V DC)। 50V से ऊपर के DC सर्किट (जैसे SMPS प्राइमरी) से दूर रहें।",
            dialSetting = "DC वोल्टेज (V⎓ या DCV) — सामान्य बैटरी/चार्जर के लिए 20V रेंज चुनें।",
            socketToUse = "काला प्रोब (Black): COM सॉकेट में | लाल प्रोब (Red): VΩmA सॉकेट में।",
            blackProbePlacement = "सर्किट के नेगेटिव (-) टर्मिनल या ग्राउंड (GND) पर रखें।",
            redProbePlacement = "सर्किट के पॉजिटिव (+) टर्मिनल पर रखें।",
            expectedReading = "AA सेल: ~1.5V | मोबाइल चार्जर: ~5.0V | 12V बैटरी: 12.2V–12.8V",
            readingMeanings = listOf(
                "0.00V: पावर नहीं आ रही या बैटरी पूरी तरह डेड है।",
                "माइनस (-) चिह्न के साथ रीडिंग (जैसे -5.0V): प्रोब उल्टे लगे हैं, चिंता की बात नहीं, बस प्रोब पलट लें।",
                "तय वोल्टेज से बहुत कम रीडिंग: बैटरी कमजोर या पावर सप्लाई में खराबी।"
            )
        ),
        MultimeterLesson(
            id = "ac_voltage",
            titleHi = "AC वोल्टेज की थ्योरी (ACV — सावधानी)",
            titleEn = "AC Voltage Theory",
            diagramType = "acv",
            isHighVoltageWarning = true,
            safetyRule = "चेतावनी: घर की 230V AC सप्लाई जानलेवा होती है। बिगिनर्स पहले केवल लो-वोल्टेज स्टेप-डाउन ट्रांसफॉर्मर (जैसे 12V AC) या थ्योरी समझें। टूटे प्रोब या गीले हाथों से कभी AC न मापें।",
            dialSetting = "AC वोल्टेज (V~ या ACV) — 230V थ्योरी के लिए 600V या 750V ACV रेंज।",
            socketToUse = "काला प्रोब: COM सॉकेट में | लाल प्रोब: VΩmA सॉकेट में (केवल CAT-II/CAT-III सुरक्षित प्रोब)।",
            blackProbePlacement = "AC में पॉजिटिव/नेगेटिव नहीं होता — न्यूट्रल (N) या ट्रांसफॉर्मर के एक सेकेंडरी तार पर (थ्योरी)।",
            redProbePlacement = "फेज (L) या ट्रांसफॉर्मर के दूसरे सेकेंडरी तार पर (केवल इंसुलेटेड हिस्से से पकड़ें)।",
            expectedReading = "भारतीय घरेलू सप्लाई: ~220V से 240V AC | 12V ट्रांसफॉर्मर आउटपुट: ~12V–14V AC",
            readingMeanings = listOf(
                "0V: सप्लाई बंद है, फ्यूज़ उड़ा है या MCB गिरी हुई है।",
                "180V से कम: लो वोल्टेज की समस्या।",
                "250V से अधिक: खतरनाक हाई वोल्टेज — उपकरण तुरंत बंद करें।"
            )
        ),
        MultimeterLesson(
            id = "resistance",
            titleHi = "रेजिस्टेंस मापना (Ω — Resistance)",
            titleEn = "Resistance Testing",
            diagramType = "ohm",
            isHighVoltageWarning = false,
            safetyRule = "सख्त नियम: रेजिस्टेंस टेस्ट केवल पावर बंद (Unplugged) और कैपेसिटर डिस्चार्ज होने के बाद ही करें! चालू सर्किट पर Ω मोड लगाने से मल्टीमीटर खराब हो सकता है।",
            dialSetting = "ओम (Ω) सेक्शन — छोटी वैल्यू के लिए 200Ω/2kΩ, बड़ी वैल्यू के लिए 20kΩ/200kΩ/2MΩ।",
            socketToUse = "काला प्रोब: COM सॉकेट | लाल प्रोब: VΩmA सॉकेट।",
            blackProbePlacement = "रेजिस्टर के किसी भी एक पैर पर रखें (रेजिस्टर में कोई + / - नहीं होता)।",
            redProbePlacement = "रेजिस्टर के दूसरे पैर पर रखें (अपनी उंगलियों से दोनों धातु सिरों को न छुएं वरना शरीर का रेजिस्टेंस जुड़ जाएगा)।",
            expectedReading = "रेजिस्टर के कलर कोड के ±5% या ±1% के अंदर (जैसे 1kΩ रेजिस्टर पर ~0.98kΩ–1.02kΩ)।",
            readingMeanings = listOf(
                "1 या OL (Over Limit): रेंज बहुत छोटी चुनी है (बड़ी रेंज चुनें) या रेजिस्टर अंदर से ओपन/जल गया है।",
                "0.00Ω: शॉर्ट सर्किट या ज़ीरो-ओम जम्पर रेजिस्टर।",
                "बढ़ी हुई वैल्यू: रेजिस्टर ओवरहीट होकर खराब हो गया है।"
            )
        ),
        MultimeterLesson(
            id = "continuity",
            titleHi = "कंटिन्यूटी टेस्ट (Beep Mode)",
            titleEn = "Continuity Testing",
            diagramType = "continuity",
            isHighVoltageWarning = false,
            safetyRule = "सख्त नियम: कंटिन्यूटी (बीप) टेस्ट कभी भी चालू (Energized) सर्किट पर न करें! पहले पावर निकालें और कैपेसिटर डिस्चार्ज करें।",
            dialSetting = "कंटिन्यूटी / बज़र आइकन (🔊 / डायोड चिह्न)।",
            socketToUse = "काला प्रोब: COM सॉकेट | लाल प्रोब: VΩmA सॉकेट।",
            blackProbePlacement = "तार, ट्रैक या स्विच के एक सिरे पर रखें।",
            redProbePlacement = "उसी तार, ट्रैक या स्विच के दूसरे सिरे पर रखें।",
            expectedReading = "लगातार बीप की आवाज़ और स्क्रीन पर 000 से 030 के आसपास रीडिंग।",
            readingMeanings = listOf(
                "बीप बजना और ~000 रीडिंग: रास्ता पूरा जुड़ा (Connected) है।",
                "कोई बीप नहीं और 1/OL रीडिंग: तार या PCB ट्रैक बीच से टूटा (Open) है।",
                "पावर लाइन (+ और GND) पर लगातार बीप: सर्किट में शॉर्ट सर्किट हो सकता है।"
            )
        ),
        MultimeterLesson(
            id = "diode_test",
            titleHi = "डायोड टेस्टिंग (Diode Mode)",
            titleEn = "Diode Testing",
            diagramType = "diode",
            isHighVoltageWarning = false,
            safetyRule = "सख्त नियम: डायोड टेस्ट केवल पावर बंद (Unplugged) अवस्था में करें। सटीक रीडिंग के लिए संभव हो तो डायोड का कम से कम एक पैर PCB से अलग करें।",
            dialSetting = "डायोड सिंबल (▶|)।",
            socketToUse = "काला प्रोब: COM सॉकेट | लाल प्रोब: VΩmA सॉकेट।",
            blackProbePlacement = "फॉरवर्ड बायस में सिल्वर पट्टी वाले सिरे (कैथोड -) पर रखें।",
            redProbePlacement = "फॉरवर्ड बायस में बिना पट्टी वाले सिरे (एनोड +) पर रखें।",
            expectedReading = "फॉरवर्ड में सिलिकॉन डायोड (1N4007): 500–700 (0.5V–0.7V) | शॉट्की डायोड: 150–350 | रिवर्स में: 1 या OL।",
            readingMeanings = listOf(
                "एक तरफ 500–700 और पलटने पर OL: डायोड बिल्कुल ठीक है।",
                "दोनों तरफ 000 और बीप: डायोड शॉर्ट (खराब) है।",
                "दोनों तरफ OL: डायोड ओपन (खराब) है।"
            )
        ),
        MultimeterLesson(
            id = "capacitor_test",
            titleHi = "कैपेसिटर टेस्टिंग",
            titleEn = "Capacitor Testing",
            diagramType = "capacitor",
            isHighVoltageWarning = false,
            safetyRule = "चेतावनी: कैपेसिटर टेस्ट करने से पहले उसे सुरक्षित तरीके से डिस्चार्ज करना अनिवार्य है! चार्ज्ड कैपेसिटर मल्टीमीटर को तुरंत खराब कर सकता है।",
            dialSetting = "कैपेसिटेंस मोड (nF / uF) यदि मीटर में हो; वरना अनप्लग अवस्था में 20kΩ या कंटिन्यूटी से बेसिक शॉर्ट जांच।",
            socketToUse = "काला प्रोब: COM सॉकेट | लाल प्रोब: VΩmA/Cx सॉकेट।",
            blackProbePlacement = "इलेक्ट्रोलाइटिक कैपेसिटर के नेगेटिव (-) पट्टी वाले पैर पर।",
            redProbePlacement = "कैपेसिटर के पॉजिटिव (+) लंबे पैर पर।",
            expectedReading = "uF मोड में: बॉडी पर लिखी वैल्यू के ±20% के अंदर। Ω मोड में: रीडिंग बढ़कर OL पर चली जानी चाहिए।",
            readingMeanings = listOf(
                "कंटिन्यूटी में लगातार बीप और 000: कैपेसिटर शॉर्ट है।",
                "ऊपरी हिस्सा फूला हुआ या तेल निकला हो: बिना टेस्ट किए ही समझें कि कैपेसिटर खराब है।",
                "uF वैल्यू लिखी वैल्यू से बहुत कम: कैपेसिटर सूख (Weak) गया है।"
            )
        ),
        MultimeterLesson(
            id = "transistor_test",
            titleHi = "ट्रांजिस्टर टेस्टिंग (NPN / PNP)",
            titleEn = "Transistor Testing",
            diagramType = "transistor",
            isHighVoltageWarning = false,
            safetyRule = "हमेशा सर्किट की पावर बंद रखकर और ट्रांजिस्टर को बोर्ड से बाहर निकालकर डायोड मोड में टेस्ट करें।",
            dialSetting = "डायोड मोड (▶|)।",
            socketToUse = "काला प्रोब: COM सॉकेट | लाल प्रोब: VΩmA सॉकेट।",
            blackProbePlacement = "NPN में पहले कलेक्टर (C) फिर एमिटर (E) पर रखें (जबकि लाल बेस B पर हो)।",
            redProbePlacement = "NPN में बेस (B) पिन पर रखें। (PNP में काला प्रोब बेस पर और लाल C/E पर)।",
            expectedReading = "B से C और B से E दोनों पर ~550–750 रीडिंग; प्रोब पलटने पर OL; C से E दोनों तरफ OL।",
            readingMeanings = listOf(
                "B-E रीडिंग B-C से थोड़ी ज़्यादा (5–20 अंक) आती है — इससे एमिटर और कलेक्टर पहचाने जाते हैं।",
                "किन्हीं भी दो पिनों के बीच 000 / बीप: ट्रांजिस्टर शॉर्ट है।",
                "किसी भी पिन पर कोई रीडिंग नहीं: ट्रांजिस्टर ओपन (खराब) है।"
            )
        ),
        MultimeterLesson(
            id = "fuse_test",
            titleHi = "फ्यूज़ टेस्टिंग",
            titleEn = "Fuse Testing",
            diagramType = "fuse",
            isHighVoltageWarning = false,
            safetyRule = "फ्यूज़ को हमेशा होल्डर से बाहर निकालकर (पावर बंद करके) ही टेस्ट करें। कभी भी फ्यूज़ की जगह मोटा कॉपर तार न बांधें!",
            dialSetting = "कंटिन्यूटी (बीप) मोड या 200Ω रेंज।",
            socketToUse = "काला प्रोब: COM सॉकेट | लाल प्रोब: VΩmA सॉकेट।",
            blackProbePlacement = "फ्यूज़ के एक धातु सिरे (End Cap) पर रखें।",
            redProbePlacement = "फ्यूज़ के दूसरे धातु सिरे पर रखें।",
            expectedReading = "बीप की आवाज़ और 0.0Ω से 0.5Ω रीडिंग।",
            readingMeanings = listOf(
                "बीप और ~0Ω: फ्यूज़ बिल्कुल सही है।",
                "कोई बीप नहीं और OL/1: फ्यूज़ उड़ (Blown) गया है।",
                "काला कांच: अंदर भारी शॉर्ट सर्किट हुआ है — नया फ्यूज़ लगाने से पहले कारण जांचें।"
            )
        ),
        MultimeterLesson(
            id = "wire_test",
            titleHi = "वायर और केबल टेस्टिंग",
            titleEn = "Wire & Cable Testing",
            diagramType = "wire",
            isHighVoltageWarning = false,
            safetyRule = "केबल को दीवार के सॉकेट और उपकरण दोनों से पूरी तरह अलग करके ही टेस्ट करें।",
            dialSetting = "कंटिन्यूटी (बीप) मोड।",
            socketToUse = "काला प्रोब: COM सॉकेट | लाल प्रोब: VΩmA सॉकेट।",
            blackProbePlacement = "केबल के एक छोर की पिन या खुले तार पर रखें।",
            redProbePlacement = "केबल के दूसरे छोर के संगत (Matching) तार पर रखें।",
            expectedReading = "स्थिर बीप की आवाज़ और ~000 रीडिंग।",
            readingMeanings = listOf(
                "केबल हिलाने पर बीप रुक-रुक कर आए: केबल अंदर से आधी टूटी (Intermittent break) है।",
                "बिल्कुल बीप नहीं: तार अंदर से पूरी तरह कटा हुआ है।",
                "दो अलग तारों के बीच बीप आए: केबल अंदर से शॉर्ट है।"
            )
        ),
        MultimeterLesson(
            id = "battery_test",
            titleHi = "बैटरी वोल्टेज चेक करना",
            titleEn = "Battery Voltage Checking",
            diagramType = "battery",
            isHighVoltageWarning = false,
            safetyRule = "बैटरी चेक करते समय हमेशा DCV मोड में रहें — कभी भी Current (10A/mA) मोड में बैटरी के दोनों सिरों पर प्रोब न लगाएं, वरना भारी शॉर्ट सर्किट होगा!",
            dialSetting = "DC वोल्टेज (20V DCV रेंज)।",
            socketToUse = "काला प्रोब: COM सॉकेट | लाल प्रोब: VΩmA सॉकेट।",
            blackProbePlacement = "बैटरी के नेगेटिव (-) सपाट सिरे पर रखें।",
            redProbePlacement = "बैटरी के पॉजिटिव (+) उभरे हुए सिरे पर रखें।",
            expectedReading = "AA/AAA: 1.5V–1.6V | 9V बैटरी: 9.0V–9.5V | 18650 लिथियम: 3.7V–4.2V | 12V बैटरी: 12.6V",
            readingMeanings = listOf(
                "AA सेल < 1.1V: सेल डिस्चार्ज हो गया है।",
                "18650 लिथियम < 2.8V: डीप डिस्चार्ज — सुरक्षित चार्जर की आवश्यकता।",
                "12V बैटरी < 11.8V: बैटरी चार्ज करने की ज़रूरत है या सेल कमजोर है।"
            )
        )
    )
}
