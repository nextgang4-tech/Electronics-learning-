package com.aielectronics.gurupro.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aielectronics.gurupro.data.AppLanguage
import com.aielectronics.gurupro.data.AppPreferences
import com.aielectronics.gurupro.data.AppSettings
import com.aielectronics.gurupro.data.ThemeMode
import com.aielectronics.gurupro.network.AiResult
import com.aielectronics.gurupro.network.GeminiApiClient
import com.aielectronics.gurupro.ui.theme.DangerRed
import com.aielectronics.gurupro.ui.theme.ElectricBlue
import com.aielectronics.gurupro.ui.theme.SafeGreen
import com.aielectronics.gurupro.ui.theme.SafetyAmber
import com.aielectronics.gurupro.util.bi
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    prefs: AppPreferences,
    currentSettings: AppSettings,
    onSettingsUpdated: (AppSettings) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lang = currentSettings.language

    var apiKey by remember(currentSettings) { mutableStateOf(currentSettings.apiKey) }
    var modelName by remember(currentSettings) { mutableStateOf(currentSettings.modelName) }
    var imageModel by remember(currentSettings) { mutableStateOf(currentSettings.imageApiModel) }
    var selectedLang by remember(currentSettings) { mutableStateOf(currentSettings.language) }
    var selectedTheme by remember(currentSettings) { mutableStateOf(currentSettings.themeMode) }
    var showKey by remember { mutableStateOf(false) }

    var testing by remember { mutableStateOf(false) }
    var testStatus by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    val presetModels = listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash")

    fun saveAll() {
        val updated = AppSettings(
            apiKey = apiKey.trim(),
            modelName = modelName.trim().ifEmpty { "gemini-2.5-flash" },
            imageApiModel = imageModel.trim(),
            language = selectedLang,
            themeMode = selectedTheme
        )
        prefs.saveSettings(updated)
        onSettingsUpdated(updated)
        Toast.makeText(context, bi(selectedLang, "सेटिंग्स सेव हो गईं!", "Settings saved!"), Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = bi(lang, "⚙️ AI और ऐप सेटिंग्स", "⚙️ AI & App Settings"),
                style = MaterialTheme.typography.titleLarge,
                color = ElectricBlue
            )
        }

        // Gemini API Configuration
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🔑 Gemini API कॉन्फ़िगरेशन", fontWeight = FontWeight.Bold, color = ElectricBlue, fontSize = 15.sp)
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Gemini API Key (केवल आपके फोन में लोकल सेव)") },
                        placeholder = { Text("AIzaSy...") },
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showKey = !showKey }) {
                                Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "Toggle key")
                            }
                        }
                    )

                    Text("मॉडल चुनें (Model):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        presetModels.forEach { m ->
                            FilterChip(
                                selected = modelName == m,
                                onClick = { modelName = m },
                                label = { Text(m.removePrefix("gemini-"), fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = modelName,
                        onValueChange = { modelName = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("कस्टम Gemini मॉडल नाम") }
                    )

                    OutlinedTextField(
                        value = imageModel,
                        onValueChange = { imageModel = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("इमेज जनरेशन मॉडल (वैकल्पिक, जैसे imagen-3.0-generate-002)") }
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { saveAll() }, modifier = Modifier.weight(1f)) {
                            Text("सेव करें (Save)")
                        }
                        OutlinedButton(
                            onClick = {
                                saveAll()
                                testStatus = null
                                scope.launch {
                                    testing = true
                                    val res = GeminiApiClient.testConnection(apiKey, modelName, selectedLang)
                                    testing = false
                                    testStatus = when (res) {
                                        is AiResult.Success -> true to "✅ कनेक्शन सफल! Gemini API काम कर रही है।"
                                        is AiResult.Error -> false to "❌ ${res.message}"
                                    }
                                }
                            },
                            enabled = !testing,
                            modifier = Modifier.weight(1f)
                        ) {
                            if (testing) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(6.dp))
                            }
                            Text("API टेस्ट करें")
                        }
                    }

                    if (testStatus != null) {
                        Text(
                            text = testStatus!!.second,
                            color = if (testStatus!!.first) SafeGreen else DangerRed,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Language & Theme
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🌐 भाषा और थीम (Language & Theme)", fontWeight = FontWeight.Bold, color = ElectricBlue, fontSize = 15.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedLang == AppLanguage.HINDI,
                            onClick = { selectedLang = AppLanguage.HINDI; saveAll() },
                            label = { Text("हिन्दी (Default)") }
                        )
                        FilterChip(
                            selected = selectedLang == AppLanguage.HINGLISH,
                            onClick = { selectedLang = AppLanguage.HINGLISH; saveAll() },
                            label = { Text("Simple Hinglish") }
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedTheme == ThemeMode.DARK,
                            onClick = { selectedTheme = ThemeMode.DARK; saveAll() },
                            label = { Text("🌙 डार्क ब्लू") }
                        )
                        FilterChip(
                            selected = selectedTheme == ThemeMode.LIGHT,
                            onClick = { selectedTheme = ThemeMode.LIGHT; saveAll() },
                            label = { Text("☀️ लाइट मोड") }
                        )
                        FilterChip(
                            selected = selectedTheme == ThemeMode.SYSTEM,
                            onClick = { selectedTheme = ThemeMode.SYSTEM; saveAll() },
                            label = { Text("सिस्टम") }
                        )
                    }
                }
            }
        }

        // Clear Data
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🧹 डेटा प्रबंधन", fontWeight = FontWeight.Bold, color = ElectricBlue, fontSize = 15.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                prefs.clearChatHistory()
                                Toast.makeText(context, "चैट हिस्ट्री साफ हो गई", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("चैट हिस्ट्री मिटाएं", fontSize = 12.sp) }
                        OutlinedButton(
                            onClick = {
                                prefs.clearSearchHistory()
                                Toast.makeText(context, "सर्च हिस्ट्री साफ हो गई", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("सर्च हिस्ट्री मिटाएं", fontSize = 12.sp) }
                    }
                }
            }
        }

        // Privacy & Production Security Info
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SafetyAmber.copy(alpha = 0.12f)), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("🔒 प्राइवेसी और API सुरक्षा जानकारी", fontWeight = FontWeight.Bold, color = SafetyAmber, fontSize = 14.sp)
                    Text(
                        text = "• इस ऐप के सोर्स कोड में कोई भी API Key हार्डकोड नहीं है।\n" +
                            "• पर्सनल टेस्टिंग के लिए आपकी API Key केवल आपके फोन के लोकल SharedPreferences में सुरक्षित रहती है।\n" +
                            "• यदि आप इस ऐप को Play Store या पब्लिक प्रोडक्शन में प्रकाशित करते हैं, तो सीधे APK में API Key उपयोग करने के बजाय एक सुरक्षित बैकएंड सर्वर (Proxy) का उपयोग करें।\n" +
                            "• आपके द्वारा चुनी गई फोटो केवल आपके द्वारा 'Analyze' दबाने पर ही आधिकारिक Google Gemini API को भेजी जाती है।",
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
