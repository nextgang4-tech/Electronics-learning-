package com.aielectronics.gurupro.data.content

import com.aielectronics.gurupro.data.ComponentPriceItem
import com.aielectronics.gurupro.data.DictionaryTerm
import com.aielectronics.gurupro.data.RepairChecklistItem
import com.aielectronics.gurupro.data.SafetyTopic

object ExtrasData {

    val safetyTopics: List<SafetyTopic> = listOf(
        SafetyTopic(
            id = "mains_230v",
            title = "230V घरेलू बिजली (Household Mains Electricity)",
            dangerLevel = "अत्यंत खतरनाक (LETHAL)",
            explanation = "भारत में घरेलू सॉकेट में 230V AC 50Hz बिजली होती है। मात्र 30mA से अधिक करंट हृदय की धड़कन रोक सकता है।",
            rule = "कभी भी प्लग लगे हुए उपकरण को न खोलें। गीले हाथों या नंगे पैरों से बिजली का काम न करें। लाइव रिपेयर योग्य इलेक्ट्रीशियन से कराएं।"
        ),
        SafetyTopic(
            id = "microwave_hv",
            title = "माइक्रोवेव हाई-वोल्टेज सर्किट (2000V–4000V)",
            dangerLevel = "जानलेवा (EXTREME DANGER)",
            explanation = "माइक्रोवेव का हाई-वोल्टेज ट्रांसफॉर्मर और कैपेसिटर 2000V से 4000V बनाता है। अनप्लग करने के बाद भी कैपेसिटर में तुरंत जान लेने लायक चार्ज रहता है।",
            rule = "बिगिनर्स माइक्रोवेव ओवन का बाहरी कवर कभी न खोलें। हमेशा अधिकृत सर्विस सेंटर से रिपेयर कराएं।"
        ),
        SafetyTopic(
            id = "crt_tv",
            title = "CRT टेलीविज़न (25,000V पिक्चर ट्यूब)",
            dangerLevel = "जानलेवा (EXTREME DANGER)",
            explanation = "पुराने बॉक्स वाले CRT TV की पिक्चर ट्यूब (Anode Cap) एक बड़े कैपेसिटर की तरह 25kV तक चार्ज रखती है — बंद होने के कई दिनों बाद भी!",
            rule = "अनट्रेन्ड यूज़र CRT TV का पिछला ढक्कन कभी न खोलें।"
        ),
        SafetyTopic(
            id = "inverter_ups",
            title = "इन्वर्टर और UPS (बैटरी से 230V AC आउटपुट)",
            dangerLevel = "अत्यंत खतरनाक (HIGH DANGER)",
            explanation = "मेन प्लग निकालने के बाद भी इन्वर्टर/UPS अपनी बैटरी से 230V AC बनाता रहता है। साथ ही बड़ी बैटरी में भारी शॉर्ट-सर्किट करंट होता है।",
            rule = "बैटरी डिस्कनेक्ट किए बिना इन्वर्टर के अंदर हाथ न डालें और धातु का औज़ार दोनों बैटरी टर्मिनल पर न लगने दें।"
        ),
        SafetyTopic(
            id = "smps_primary",
            title = "SMPS प्राइमरी (HOT) साइड",
            dangerLevel = "अत्यंत खतरनाक (HIGH DANGER)",
            explanation = "चार्जर, TV और कंप्यूटर SMPS के प्राइमरी हिस्से में 230V AC सीधे ~320V DC में बदला जाता है और यह मेन लाइन से आइसोलेटेड नहीं होता।",
            rule = "SMPS के HOT सेक्शन पर प्लग लगे हुए कभी टेस्टिंग या हाथ न लगाएं।"
        ),
        SafetyTopic(
            id = "hv_capacitors",
            title = "हाई-वोल्टेज कैपेसिटर (चार्ज जमा रहना)",
            dangerLevel = "खतरनाक (DANGER)",
            explanation = "बड़े 400V/450V इलेक्ट्रोलाइटिक कैपेसिटर प्लग निकालने के बाद भी कई मिनटों या घंटों तक खतरनाक वोल्टेज स्टोर करके रखते हैं।",
            rule = "कभी न मानें कि अनप्लग करने से कैपेसिटर खाली हो गया है। बड़े HV कैपेसिटर को स्क्रूड्राइवर से शॉर्ट न करें (तेज़ स्पार्क होता है) — योग्य तकनीक से ही डिस्चार्ज किया जाता है।"
        ),
        SafetyTopic(
            id = "lithium_packs",
            title = "लिथियम-आयन / LiPo बैटरी पैक",
            dangerLevel = "आग और विस्फोट का खतरा (FIRE HAZARD)",
            explanation = "लिथियम बैटरी को शॉर्ट करने, ओवरचार्ज करने, गर्म करने या छेदने से थर्मल रनअवे (अचानक आग और जहरीला धुआं) हो सकता है।",
            rule = "फूली हुई बैटरी तुरंत उपयोग करना बंद करें। बैटरी के + और - कभी शॉर्ट न करें।"
        ),
        SafetyTopic(
            id = "high_current_batteries",
            title = "हाई-करंट बैटरी सिस्टम (कार / इन्वर्टर / ई-रिक्शा)",
            dangerLevel = "आग व स्पार्क का खतरा (HIGH CURRENT)",
            explanation = "12V–48V की बड़ी बैटरी में वोल्टेज कम होने के बावजूद सैकड़ों एम्पियर करंट होता है जो धातु के औज़ार को सेकंडों में पिघलाकर आग लगा सकता है।",
            rule = "काम करते समय धातु की अंगूठी/घड़ी उतार दें और इंसुलेटेड टूल्स ही उपयोग करें।"
        )
    )

    val dictionaryTerms: List<DictionaryTerm> = listOf(
        DictionaryTerm("AC (Alternating Current)", "प्रत्यावर्ती धारा — जो लगातार दिशा बदलती है।", "घर के 230V सॉकेट की बिजली।"),
        DictionaryTerm("DC (Direct Current)", "दिष्ट धारा — जो हमेशा एक दिशा (+ से -) में बहती है।", "बैटरी और 5V मोबाइल चार्जर।"),
        DictionaryTerm("Voltage (वोल्टेज - V)", "विद्युत दबाव जो करंट को सर्किट में चलाता है।", "1.5V सेल या 12V एडॉप्टर।"),
        DictionaryTerm("Current (करंट - A / mA)", "इलेक्ट्रॉनों के बहाव की दर।", "2A फास्ट चार्जर करंट।"),
        DictionaryTerm("Resistance (रेजिस्टेंस - Ω)", "करंट के बहाव में डाली जाने वाली रुकावट।", "LED के साथ लगा 220Ω रेजिस्टर।"),
        DictionaryTerm("Power (पावर - Watt)", "बिजली खर्च होने की दर (P = V × I)।", "9W LED बल्ब।"),
        DictionaryTerm("PCB (Printed Circuit Board)", "इलेक्ट्रॉनिक बोर्ड जिस पर कॉपर ट्रैक और कंपोनेंट लगे होते हैं।", "चार्जर या रिमोट के अंदर का हरा बोर्ड।"),
        DictionaryTerm("SMD (Surface Mount Device)", "बहुत छोटे कंपोनेंट जो PCB की सतह पर सीधे सोल्डर होते हैं।", "मोबाइल मदरबोर्ड के छोटे पार्ट्स।"),
        DictionaryTerm("Through-Hole", "लंबे पैरों वाले कंपोनेंट जो PCB के छेदों में डालकर सोल्डर होते हैं।", "बड़ा इलेक्ट्रोलाइटिक कैपेसिटर।"),
        DictionaryTerm("Continuity (कंटिन्यूटी)", "दो बिंदुओं के बीच बिना टूटे सीधा जुड़ाव।", "मल्टीमीटर बीप से तार चेक करना।"),
        DictionaryTerm("Short Circuit (शॉर्ट सर्किट)", "+ और - का बिना लोड के सीधे जुड़ जाना, जिससे भारी करंट बहता है।", "शॉर्ट डायोड से फ्यूज़ उड़ना।"),
        DictionaryTerm("Open Circuit (ओपन सर्किट)", "सर्किट का रास्ता बीच से टूट जाना, जिससे करंट बंद हो जाता है।", "कटा हुआ तार या उड़ा हुआ फ्यूज़।"),
        DictionaryTerm("GND (Ground / ग्राउंड)", "सर्किट का 0V संदर्भ बिंदु (आमतौर पर नेगेटिव -)।", "बैटरी का नेगेटिव टर्मिनल।"),
        DictionaryTerm("VCC / VDD", "सर्किट या IC की पॉजिटिव DC पावर सप्लाई लाइन।", "Arduino की +5V पिन।"),
        DictionaryTerm("SMPS", "Switched Mode Power Supply — हाई-फ़्रीक्वेंसी कुशल पावर सप्लाई।", "मोबाइल और लैपटॉप चार्जर।"),
        DictionaryTerm("Rectifier (रेक्टिफायर)", "AC को DC में बदलने वाला डायोड सर्किट।", "4 डायोड का ब्रिज रेक्टिफायर।"),
        DictionaryTerm("Ripple (रिपल)", "DC वोल्टेज में बची हुई हल्की AC लहरें।", "कमजोर फ़िल्टर कैपेसिटर से हमिंग आना।"),
        DictionaryTerm("Cold Solder Joint", "खराब सोल्डर जोड़ जो ठीक से पिघला या चिपका नहीं।", "हिलाने पर डिवाइस चालू-बंद होना।"),
        DictionaryTerm("Flux (फ्लक्स)", "रासायनिक पेस्ट जो सोल्डरिंग के समय ऑक्साइड हटाकर मजबूत जोड़ बनाता है।", "रोसिन सोल्डरिंग पेस्ट।"),
        DictionaryTerm("ESD (Electrostatic Discharge)", "शरीर की स्टैटिक बिजली का झटका जो नाज़ुक IC/MOSFET खराब कर सकता है।", "सर्दियों में स्वेटर से चिंगारी।"),
        DictionaryTerm("Polarity (पोलैरिटी)", "कंपोनेंट की सही + और - दिशा।", "LED और इलेक्ट्रोलाइटिक कैपेसिटर।"),
        DictionaryTerm("Anode / Cathode", "डायोड या LED का पॉजिटिव (+) सिरा एनोड और नेगेटिव (-) कैथोड।", "डायोड की सिल्वर पट्टी = कैथोड।"),
        DictionaryTerm("Optocoupler (ऑप्टोकपलर)", "रोशनी के ज़रिए दो अलग सर्किट के बीच सुरक्षित सिग्नल भेजने वाली IC।", "SMPS में PC817 IC।"),
        DictionaryTerm("MOV (Metal Oxide Varistor)", "अचानक आने वाले हाई-वोल्टेज सर्ज से बचाने वाला कंपोनेंट।", "LED बल्ब के इनपुट पर नीला डिस्क।"),
        DictionaryTerm("BMS (Battery Management System)", "लिथियम बैटरी को ओवरचार्ज, ओवर-डिस्चार्ज और शॉर्ट से बचाने वाला बोर्ड।", "पावरबैंक या ई-बाइक बैटरी पैक।"),
        DictionaryTerm("Heat Sink (हीटसिंक)", "एल्युमीनियम की प्लेट जो गर्म IC/MOSFET की गर्मी हवा में छोड़ती है।", "एम्पलीफायर में TDA2030 पर लगी प्लेट।"),
        DictionaryTerm("PWM (Pulse Width Modulation)", "तेज़ी से ऑन-ऑफ करके मोटर की स्पीड या LED की चमक नियंत्रित करना।", "फैन और SMPS कंट्रोलर।"),
        DictionaryTerm("Datasheet (डेटाशीट)", "कंपोनेंट निर्माता का आधिकारिक दस्तावेज़ जिसमें पिनआउट और लिमिट लिखी होती है।", "7805 या BC547 की डेटाशीट।")
    )

    val defaultComponentPrices: List<ComponentPriceItem> = listOf(
        ComponentPriceItem("p1", "1/4W रेजिस्टर (सामान्य)", "10Ω–1MΩ", 2),
        ComponentPriceItem("p2", "इलेक्ट्रोलाइटिक कैपेसिटर", "1000uF 25V", 10),
        ComponentPriceItem("p3", "मेन SMPS कैपेसिटर", "47uF–100uF 450V", 35),
        ComponentPriceItem("p4", "1N4007 डायोड", "1A 1000V", 3),
        ComponentPriceItem("p5", "5mm LED (लाल/हरा/सफेद)", "3V 20mA", 3),
        ComponentPriceItem("p6", "BC547 / BC557 ट्रांजिस्टर", "TO-92 NPN/PNP", 5),
        ComponentPriceItem("p7", "IRFZ44N MOSFET", "55V 49A TO-220", 30),
        ComponentPriceItem("p8", "7805 वोल्टेज रेगुलेटर", "5V 1A TO-220", 15),
        ComponentPriceItem("p9", "TDA2030A ऑडियो IC", "18W Audio Amp", 35),
        ComponentPriceItem("p10", "PAM8403 मिनी ऑडियो मॉड्यूल", "5V 3W+3W Stereo", 45),
        ComponentPriceItem("p11", "TP4056 लिथियम चार्जर मॉड्यूल", "Type-C 1A 1S", 35),
        ComponentPriceItem("p12", "PC817 ऑप्टोकपलर", "4-Pin DIP/SMD", 10),
        ComponentPriceItem("p13", "फैन कैपेसिटर", "2.5uF 440V AC", 40),
        ComponentPriceItem("p14", "9W LED MCPCB प्लेट", "DOB / Driver Type", 25),
        ComponentPriceItem("p15", "ग्लास फ्यूज़", "2A / 5A 250V", 5),
        ComponentPriceItem("p16", "12V 10A रिले (5-Pin)", "SRD-12VDC", 35),
        ComponentPriceItem("p17", "18650 लिथियम सेल", "3.7V 2000mAh", 110),
        ComponentPriceItem("p18", "Micro-USB / Type-C जैक", "चार्जिंग कनेक्टर", 20)
    )

    val repairChecklist: List<RepairChecklistItem> = listOf(
        RepairChecklistItem("c1", "1. पावर सप्लाई अनप्लग करें", "कोई भी कवर खोलने से पहले मेन प्लग और बैटरी पूरी तरह अलग करें।"),
        RepairChecklistItem("c2", "2. हाई-वोल्टेज खतरा जांचें", "क्या यह 230V, माइक्रोवेव, CRT, इन्वर्टर या SMPS प्राइमरी है? यदि हां, तो लाइव रिपेयर न करें।"),
        RepairChecklistItem("c3", "3. बाहरी केबल, स्विच और बैटरी जांचें", "अक्सर समस्या केवल ढीली केबल, गंदे सॉकेट या कमजोर सेल से होती है।"),
        RepairChecklistItem("c4", "4. खोलने से पहले फोटो खींचें", "हर स्क्रू, तार और कनेक्टर की पोजीशन याद रखने के लिए फोटो ले लें।"),
        RepairChecklistItem("c5", "5. कैपेसिटर डिस्चार्ज की पुष्टि करें", "बड़े कैपेसिटर में अनप्लग के बाद भी चार्ज हो सकता है।"),
        RepairChecklistItem("c6", "6. अच्छी रोशनी में विज़ुअल जांच करें", "जले निशान, फूले कैपेसिटर, जंग (Corrosion), टूटे ट्रैक और कोल्ड सोल्डर देखें।"),
        RepairChecklistItem("c7", "7. अनप्लग अवस्था में फ्यूज़ और शॉर्टिंग चेक करें", "कंटिन्यूटी/ओम मोड केवल पावर बंद अवस्था में ही उपयोग करें।"),
        RepairChecklistItem("c8", "8. संदिग्ध कंपोनेंट की पुष्टि करें", "सटीक जांच के लिए ज़रूरत हो तो एक लेग अलग करके दोबारा मापें।"),
        RepairChecklistItem("c9", "9. सही वैल्यू और पोलैरिटी (+ / -) मिलाएं", "नया पार्ट लगाने से पहले वोल्टेज, करंट, और + / - दिशा दो बार चेक करें।"),
        RepairChecklistItem("c10", "10. सोल्डर ब्रिज और फ्लक्स साफ करें", "IPA से बोर्ड साफ करें और पास की पिनों में शॉर्ट न होने की जांच करें।"),
        RepairChecklistItem("c11", "11. सुरक्षित टेस्टिंग और री-असेंबली", "सभी स्क्रू और इंसुलेशन शीट वापस सही जगह लगाकर ही टेस्ट करें।"),
        RepairChecklistItem("c12", "12. रिपेयर नोट्स सेव करें", "भविष्य के लिए फॉल्ट और समाधान को Repair Notes में दर्ज करें।")
    )
}
